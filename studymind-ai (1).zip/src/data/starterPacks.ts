import { StudyMaterial, FlashcardItem, QuizQuestion } from '../types';
import { countWords, estimateReadingTime } from '../domain/textExtractor';

export const STARTER_MATERIALS: StudyMaterial[] = [
  {
    id: 'doc-maths-101',
    title: 'Engineering Mathematics: Linear Algebra, Calculus & Probability',
    subject: 'Maths',
    content: `Engineering Mathematics provides the rigorous analytical foundation for computer science and engineering disciplines.

1. Linear Algebra & Matrix Transformations:
- Matrices represent linear transformations in vector spaces. For an n x n matrix A, an eigenvector v and eigenvalue λ satisfy the characteristic equation: A * v = λ * v, or (A - λI) * v = 0.
- The eigenvalues are determined by finding the roots of the characteristic polynomial: det(A - λI) = 0.
- Orthogonality and Decomposition: Singular Value Decomposition (SVD) factors any matrix A into U * Σ * V^T, which is essential for Principal Component Analysis (PCA) and dimensionality reduction.

2. Multivariable Calculus & Optimization:
- The Gradient ∇f of a scalar function f(x, y, z) is a vector pointing in the direction of greatest rate of increase: ∇f = [∂f/∂x, ∂f/∂y, ∂f/∂z].
- In Gradient Descent optimization, parameters θ are updated iteratively along the negative gradient: θ := θ - α * ∇L(θ), where α is the learning rate.
- The Hessian Matrix H contains second-order partial derivatives and reveals the curvature of the loss surface: local minimum when H is positive definite.

3. Probability & Statistics:
- Bayes' Theorem relates conditional probabilities: P(A|B) = [P(B|A) * P(A)] / P(B).
- Discrete vs Continuous Distributions: Binomial and Poisson distributions model count events, while the Normal (Gaussian) distribution underlies the Central Limit Theorem (CLT).`,
    wordCount: 220,
    readingTimeMinutes: 2,
    createdAt: Date.now() - 3600000 * 48,
    isPreloaded: true,
    summary: 'High-yield overview of Engineering Mathematics covering Matrix Eigenvalues, SVD, Multivariable Gradients for Gradient Descent optimization, and Bayes\' Probability Theorem.',
    keyTakeaways: [
      'Eigenvalues solve det(A - λI) = 0; eigenvectors define transformation invariant axes.',
      'The Gradient vector ∇f points toward the steepest ascent; negative gradient descends toward local minima.',
      'Bayes\' Rule calculates posterior probability P(A|B) from prior P(A) and likelihood P(B|A).'
    ]
  },
  {
    id: 'doc-dsa-102',
    title: 'Data Structures & Algorithms: Trees, Graphs & Dynamic Programming',
    subject: 'DSA',
    content: `Data Structures organize data efficiently, while Algorithms provide step-by-step procedures to solve computational problems.

1. Asymptotic Complexity (Big-O Notation):
- Measures algorithmic scaling in time and space as input size n grows to infinity.
- Hierarchy: O(1) < O(log n) < O(n) < O(n log n) < O(n^2) < O(2^n) < O(n!).

2. Non-Linear Data Structures (Trees & Heaps):
- Binary Search Tree (BST): For each node, all left descendants have values < node.val, and right descendants have values > node.val. Average search is O(log n), but degrades to O(n) if unbalanced.
- Self-Balancing Trees (AVL & Red-Black Trees): Enforce height balance factors to guarantee worst-case O(log n) insertions, deletions, and lookups.
- Binary Min/Max Heap: Complete binary tree satisfying the heap property (parent <= children in Min-Heap). Find-min is O(1); insertion and deletion are O(log n).

3. Graph Algorithms:
- Breadth-First Search (BFS): Uses a Queue; explores vertices level-by-level; finds shortest paths in unweighted graphs in O(V + E) time.
- Depth-First Search (DFS): Uses recursion/Stack; explores deeply before backtracking; used in cycle detection and topological sorting.
- Dijkstra's Algorithm: Uses a Priority Queue to compute single-source shortest paths in non-negative weighted graphs in O((V + E) log V).

4. Dynamic Programming (DP):
- Solves problems exhibiting Overlapping Subproblems and Optimal Substructure.
- Top-Down with Memoization: Caches recursive branch results.
- Bottom-Up with Tabulation: Iteratively builds optimal solutions from base cases in a DP table.`,
    wordCount: 245,
    readingTimeMinutes: 2,
    createdAt: Date.now() - 3600000 * 36,
    isPreloaded: true,
    summary: 'Fundamental DSA curriculum: Big-O complexity, self-balancing BSTs and Heaps, Graph traversals (BFS, DFS, Dijkstra), and Dynamic Programming patterns.',
    keyTakeaways: [
      'Balanced BSTs guarantee O(log n) operations; unweighted graph shortest path is solved via BFS in O(V + E).',
      'Dijkstra\'s greedy shortest path algorithm requires non-negative edge weights.',
      'Dynamic programming solves overlapping subproblems by memoizing or tabulating optimal sub-solutions.'
    ]
  },
  {
    id: 'doc-java-103',
    title: 'Java Programming: OOP, JVM Memory & Concurrency',
    subject: 'Java',
    content: `Java is a high-level, class-based, object-oriented programming language designed around the 'Write Once, Run Anywhere' (WORA) philosophy.

1. Object-Oriented Principles:
- Encapsulation: Restricting direct access to state via private fields and public getters/setters.
- Inheritance: Subclasses inherit state and behavior using the 'extends' keyword.
- Polymorphism: Method Overloading (compile-time) and Method Overriding (runtime dynamic dispatch via virtual method table).
- Abstraction: Interfaces and abstract classes define contracts without prescribing internal implementation.

2. JVM Architecture & Memory Model:
- Stack Memory: Stores primitive variables and references to heap objects within thread execution frames. Created and freed automatically per method invocation.
- Heap Memory: Stores all object instances and class data. Managed by automatic Garbage Collection (e.g., G1 GC, ZGC) partitioned into Young Generation (Eden, Survivor) and Old/Tenured Generation.

3. Java Collections Framework:
- List: Ordered sequences (ArrayList offers O(1) indexed access; LinkedList offers fast node insertion).
- Map: Key-value associations. HashMap uses an array of buckets with hashing and resolves collisions via linked nodes, converting to a Red-Black tree when bucket size exceeds 8 (TREEIFY_THRESHOLD).
- Set: Unique elements (HashSet backed internally by HashMap).

4. Concurrency & Modern Java 21:
- Synchronization: 'synchronized' blocks and Locks coordinate shared mutable state to avoid race conditions.
- Virtual Threads (Project Loom): Lightweight JVM-managed threads allowing millions of concurrent tasks with minimal memory overhead.`,
    wordCount: 230,
    readingTimeMinutes: 2,
    createdAt: Date.now() - 3600000 * 24,
    isPreloaded: true,
    summary: 'Complete Java guide: 4 pillars of OOP, JVM Stack vs Heap architecture, Garbage Collection phases, Collections internals (HashMap treeification), and Java 21 Virtual Threads.',
    keyTakeaways: [
      'Objects reside on the Heap managed by Garbage Collection; method execution frames reside on the Stack.',
      'HashMap buckets convert from linked lists to Red-Black trees when bucket collisions exceed 8.',
      'Java 21 Virtual Threads enable high-throughput concurrent I/O without native OS thread exhaustion.'
    ]
  },
  {
    id: 'doc-de-104',
    title: 'Digital Electronics: Logic Gates, Boolean Algebra & Flip-Flops',
    subject: 'Digital Electronics',
    content: `Digital Electronics studies systems that operate on discrete binary electrical signals representing 0 (LOW) and 1 (HIGH).

1. Boolean Algebra & Logic Gates:
- Basic Gates: AND (output HIGH if all inputs HIGH), OR (output HIGH if any input HIGH), NOT (Inverter).
- Universal Gates: NAND and NOR. Any boolean function or circuit can be implemented using exclusively NAND or exclusively NOR gates.
- De Morgan's Theorems:
  1. (A • B)' = A' + B' (NAND equals negative OR)
  2. (A + B)' = A' • B' (NOR equals negative AND)

2. Combinational Logic Circuits:
- Output depends solely on the current input combination (no memory).
- Karnaugh Maps (K-Maps): Graphical tool using Gray code ordering to group adjacent 1s (in powers of 2: 1, 2, 4, 8) to find Minimal Sum of Products (SOP) expressions.
- Multiplexers (MUX): 'Data selectors' with 2^n data inputs, n select lines, and 1 output.
- Adders: Half Adder (adds 2 bits: Sum = A ⊕ B, Carry = A • B); Full Adder (adds 3 bits including Carry-in).

3. Sequential Logic & Memory Elements:
- Output depends on current inputs AND previous state (contains memory / feedback loops).
- Latches vs Flip-Flops: Latches are level-triggered; Flip-Flops are edge-triggered (synchronous clock transitions).
- SR Flip-Flop: Set and Reset. Condition S=1, R=1 is forbidden (invalid state).
- JK Flip-Flop: Solves SR invalid state. When J=1, K=1, the output toggles (Q_next = Q').
- Race Around Condition: Occurs in level-triggered JK flip-flops when clock pulse width > propagation delay; resolved by Master-Slave JK configuration or edge-triggering.
- D Flip-Flop (Data/Delay): Q_next = D. Primary building block for registers and computer RAM.`,
    wordCount: 275,
    readingTimeMinutes: 2,
    createdAt: Date.now() - 3600000 * 12,
    isPreloaded: true,
    summary: 'Comprehensive Digital Electronics syllabus: Boolean theorems, Universal gates (NAND/NOR), K-Map minimization, Multiplexers, and Sequential logic (SR, JK, D Flip-Flops & race-around solutions).',
    keyTakeaways: [
      'NAND and NOR are universal gates capable of implementing any boolean function.',
      'De Morgan\'s law: (A • B)\' = A\' + B\' and (A + B)\' = A\' • B\'.',
      'JK Flip-Flop toggles when J=K=1; Master-Slave design prevents race around conditions.'
    ]
  }
];

// Calculate precise word counts
STARTER_MATERIALS.forEach(mat => {
  mat.wordCount = countWords(mat.content);
  mat.readingTimeMinutes = estimateReadingTime(mat.wordCount);
});

export const STARTER_FLASHCARDS: FlashcardItem[] = [
  // Maths
  {
    id: 'fc-m-1',
    documentId: 'doc-maths-101',
    question: 'How are eigenvalues of a square matrix A calculated?',
    answer: 'By solving the characteristic polynomial equation: det(A - λI) = 0.',
    topic: 'Linear Algebra',
    difficulty: 'Medium',
    repetitionIntervalDays: 1,
    easeFactor: 2.5,
    reviewCount: 0,
    lastReviewedTimestamp: 0,
    isBookmarked: false,
  },
  {
    id: 'fc-m-2',
    documentId: 'doc-maths-101',
    question: 'What does the gradient vector ∇f physically represent?',
    answer: 'A vector pointing in the direction of the greatest rate of increase of function f, with magnitude equal to that slope.',
    topic: 'Calculus',
    difficulty: 'Easy',
    repetitionIntervalDays: 1,
    easeFactor: 2.5,
    reviewCount: 0,
    lastReviewedTimestamp: 0,
    isBookmarked: false,
  },
  {
    id: 'fc-m-3',
    documentId: 'doc-maths-101',
    question: 'State Bayes\' Theorem formula and its components.',
    answer: 'P(A|B) = [P(B|A) * P(A)] / P(B), where P(A|B) is posterior, P(B|A) is likelihood, P(A) is prior, and P(B) is evidence.',
    topic: 'Probability',
    difficulty: 'Medium',
    repetitionIntervalDays: 1,
    easeFactor: 2.5,
    reviewCount: 0,
    lastReviewedTimestamp: 0,
    isBookmarked: false,
  },
  {
    id: 'fc-m-4',
    documentId: 'doc-maths-101',
    question: 'What is Singular Value Decomposition (SVD)?',
    answer: 'Factoring matrix A into U * Σ * V^T, where U and V are orthogonal matrices and Σ contains singular values.',
    topic: 'Linear Algebra',
    difficulty: 'Hard',
    repetitionIntervalDays: 1,
    easeFactor: 2.5,
    reviewCount: 0,
    lastReviewedTimestamp: 0,
    isBookmarked: false,
  },
  {
    id: 'fc-m-5',
    documentId: 'doc-maths-101',
    question: 'In Gradient Descent, how is the parameter update rule defined?',
    answer: 'θ := θ - α * ∇L(θ), where α is the learning rate and ∇L(θ) is the gradient of the loss.',
    topic: 'Optimization',
    difficulty: 'Easy',
    repetitionIntervalDays: 1,
    easeFactor: 2.5,
    reviewCount: 0,
    lastReviewedTimestamp: 0,
    isBookmarked: false,
  },

  // DSA
  {
    id: 'fc-dsa-1',
    documentId: 'doc-dsa-102',
    question: 'What is the worst-case time complexity of an unbalanced BST search versus an AVL tree search?',
    answer: 'Unbalanced BST is O(n) (degraded to linked list); AVL tree is strictly O(log n) due to height balancing.',
    topic: 'Trees',
    difficulty: 'Medium',
    repetitionIntervalDays: 1,
    easeFactor: 2.5,
    reviewCount: 0,
    lastReviewedTimestamp: 0,
    isBookmarked: false,
  },
  {
    id: 'fc-dsa-2',
    documentId: 'doc-dsa-102',
    question: 'Which data structures power BFS and DFS respectively?',
    answer: 'Queue is used for Breadth-First Search (BFS); Stack (or call stack recursion) is used for Depth-First Search (DFS).',
    topic: 'Graphs',
    difficulty: 'Easy',
    repetitionIntervalDays: 1,
    easeFactor: 2.5,
    reviewCount: 0,
    lastReviewedTimestamp: 0,
    isBookmarked: false,
  },
  {
    id: 'fc-dsa-3',
    documentId: 'doc-dsa-102',
    question: 'What is the core prerequisite for using Dijkstra\'s shortest path algorithm?',
    answer: 'All edge weights must be non-negative. For graphs with negative edge weights, Bellman-Ford must be used.',
    topic: 'Graphs',
    difficulty: 'Medium',
    repetitionIntervalDays: 1,
    easeFactor: 2.5,
    reviewCount: 0,
    lastReviewedTimestamp: 0,
    isBookmarked: false,
  },
  {
    id: 'fc-dsa-4',
    documentId: 'doc-dsa-102',
    question: 'What are the two key properties required for Dynamic Programming?',
    answer: '1. Overlapping Subproblems\n2. Optimal Substructure',
    topic: 'Dynamic Programming',
    difficulty: 'Easy',
    repetitionIntervalDays: 1,
    easeFactor: 2.5,
    reviewCount: 0,
    lastReviewedTimestamp: 0,
    isBookmarked: false,
  },
  {
    id: 'fc-dsa-5',
    documentId: 'doc-dsa-102',
    question: 'What are the average time complexities for Binary Heap insert and extract-min?',
    answer: 'Insert: O(log n); Extract-Min: O(log n); Find-Min: O(1).',
    topic: 'Heaps',
    difficulty: 'Hard',
    repetitionIntervalDays: 1,
    easeFactor: 2.5,
    reviewCount: 0,
    lastReviewedTimestamp: 0,
    isBookmarked: false,
  },

  // Java
  {
    id: 'fc-j-1',
    documentId: 'doc-java-103',
    question: 'What is the fundamental difference between JVM Stack and Heap memory?',
    answer: 'Stack stores local primitive variables and method call frames per thread; Heap stores object instances shared across threads.',
    topic: 'JVM Memory',
    difficulty: 'Medium',
    repetitionIntervalDays: 1,
    easeFactor: 2.5,
    reviewCount: 0,
    lastReviewedTimestamp: 0,
    isBookmarked: false,
  },
  {
    id: 'fc-j-2',
    documentId: 'doc-java-103',
    question: 'How does Java HashMap handle high collision counts in a single bucket?',
    answer: 'When a bucket contains more than 8 elements (TREEIFY_THRESHOLD) and capacity >= 64, the linked list converts to a Red-Black tree.',
    topic: 'Collections',
    difficulty: 'Hard',
    repetitionIntervalDays: 1,
    easeFactor: 2.5,
    reviewCount: 0,
    lastReviewedTimestamp: 0,
    isBookmarked: false,
  },
  {
    id: 'fc-j-3',
    documentId: 'doc-java-103',
    question: 'What are the four pillars of Object-Oriented Programming (OOP)?',
    answer: '1. Encapsulation\n2. Abstraction\n3. Inheritance\n4. Polymorphism',
    topic: 'OOP',
    difficulty: 'Easy',
    repetitionIntervalDays: 1,
    easeFactor: 2.5,
    reviewCount: 0,
    lastReviewedTimestamp: 0,
    isBookmarked: false,
  },
  {
    id: 'fc-j-4',
    documentId: 'doc-java-103',
    question: 'What are Java 21 Virtual Threads and how do they differ from Platform Threads?',
    answer: 'Virtual Threads are lightweight JVM-scheduled threads (Project Loom) decoupled from 1:1 OS threads, enabling massive concurrency.',
    topic: 'Java 21',
    difficulty: 'Medium',
    repetitionIntervalDays: 1,
    easeFactor: 2.5,
    reviewCount: 0,
    lastReviewedTimestamp: 0,
    isBookmarked: false,
  },
  {
    id: 'fc-j-5',
    documentId: 'doc-java-103',
    question: 'Explain compile-time vs runtime polymorphism in Java.',
    answer: 'Compile-time polymorphism is method overloading (same name, distinct signatures); runtime polymorphism is method overriding via dynamic dispatch.',
    topic: 'OOP',
    difficulty: 'Easy',
    repetitionIntervalDays: 1,
    easeFactor: 2.5,
    reviewCount: 0,
    lastReviewedTimestamp: 0,
    isBookmarked: false,
  },

  // Digital Electronics
  {
    id: 'fc-de-1',
    documentId: 'doc-de-104',
    question: 'Why are NAND and NOR called \'Universal Gates\'?',
    answer: 'Because any boolean logic function, circuit, or flip-flop can be constructed using only NAND gates or only NOR gates.',
    topic: 'Logic Gates',
    difficulty: 'Easy',
    repetitionIntervalDays: 1,
    easeFactor: 2.5,
    reviewCount: 0,
    lastReviewedTimestamp: 0,
    isBookmarked: false,
  },
  {
    id: 'fc-de-2',
    documentId: 'doc-de-104',
    question: 'State both of De Morgan\'s Laws.',
    answer: '1. (A • B)\' = A\' + B\'\n2. (A + B)\' = A\' • B\'',
    topic: 'Boolean Algebra',
    difficulty: 'Easy',
    repetitionIntervalDays: 1,
    easeFactor: 2.5,
    reviewCount: 0,
    lastReviewedTimestamp: 0,
    isBookmarked: false,
  },
  {
    id: 'fc-de-3',
    documentId: 'doc-de-104',
    question: 'What is the \'Race Around Condition\' in a JK Flip-Flop and how is it resolved?',
    answer: 'When J=1, K=1 and clock pulse width > propagation delay, output toggles uncontrollably. Resolved using Master-Slave JK or edge-triggering.',
    topic: 'Sequential Circuits',
    difficulty: 'Hard',
    repetitionIntervalDays: 1,
    easeFactor: 2.5,
    reviewCount: 0,
    lastReviewedTimestamp: 0,
    isBookmarked: false,
  },
  {
    id: 'fc-de-4',
    documentId: 'doc-de-104',
    question: 'What is the primary difference between a Latch and a Flip-Flop?',
    answer: 'A latch is level-triggered (transparent while clock is HIGH/LOW); a flip-flop is edge-triggered (changes state only on clock transition).',
    topic: 'Sequential Circuits',
    difficulty: 'Medium',
    repetitionIntervalDays: 1,
    easeFactor: 2.5,
    reviewCount: 0,
    lastReviewedTimestamp: 0,
    isBookmarked: false,
  },
  {
    id: 'fc-de-5',
    documentId: 'doc-de-104',
    question: 'How does a Multiplexer (MUX) with n select lines work?',
    answer: 'It routes one of 2^n data input channels to a single output line based on the binary combination on the n select lines.',
    topic: 'Combinational Logic',
    difficulty: 'Medium',
    repetitionIntervalDays: 1,
    easeFactor: 2.5,
    reviewCount: 0,
    lastReviewedTimestamp: 0,
    isBookmarked: false,
  }
];

export const STARTER_QUIZZES: QuizQuestion[] = [
  // Maths
  {
    id: 'q-m-1',
    documentId: 'doc-maths-101',
    questionText: 'What is the condition for matrix A to have λ as an eigenvalue?',
    options: ['det(A - λI) = 0', 'Trace(A) = λ', 'det(A) = λ', 'A * I = 0'],
    correctAnswerIndex: 0,
    explanation: 'The characteristic equation det(A - λI) = 0 yields non-trivial solutions (eigenvectors) for eigenvalue λ.'
  },
  {
    id: 'q-m-2',
    documentId: 'doc-maths-101',
    questionText: 'In which direction does the negative gradient -∇f point?',
    options: [
      'Direction of maximum rate of increase',
      'Direction of steepest decrease / descent',
      'Orthogonal to contour lines only',
      'Along the tangent plane'
    ],
    correctAnswerIndex: 1,
    explanation: 'The gradient ∇f points along steepest ascent; hence -∇f points in the direction of steepest descent, forming the basis of Gradient Descent.'
  },
  {
    id: 'q-m-3',
    documentId: 'doc-maths-101',
    questionText: 'According to Bayes\' Theorem, what does P(B|A) represent in P(A|B) = [P(B|A) * P(A)] / P(B)?',
    options: ['Prior Probability', 'Posterior Probability', 'Likelihood', 'Marginal Evidence'],
    correctAnswerIndex: 2,
    explanation: 'P(B|A) is the Likelihood: the probability of observing evidence B given hypothesis A is true.'
  },

  // DSA
  {
    id: 'q-dsa-1',
    documentId: 'doc-dsa-102',
    questionText: 'Which graph traversal algorithm guarantees the shortest path in an unweighted graph?',
    options: ['Depth-First Search (DFS)', 'Breadth-First Search (BFS)', 'Prim\'s Algorithm', 'Topological Sort'],
    correctAnswerIndex: 1,
    explanation: 'BFS traverses vertices layer-by-layer in increasing order of distance, ensuring the first time a vertex is visited is via the shortest path in unweighted graphs.'
  },
  {
    id: 'q-dsa-2',
    documentId: 'doc-dsa-102',
    questionText: 'What is the worst-case time complexity of searching an element in an AVL Tree with n nodes?',
    options: ['O(1)', 'O(log n)', 'O(n)', 'O(n log n)'],
    correctAnswerIndex: 1,
    explanation: 'Because AVL trees maintain strict height balance factors (-1, 0, +1), the tree height is bounded by 1.44 log n, guaranteeing O(log n) search.'
  },
  {
    id: 'q-dsa-3',
    documentId: 'doc-dsa-102',
    questionText: 'Why will Dijkstra\'s algorithm fail on graphs with negative edge weights?',
    options: [
      'It cannot handle directed graphs',
      'Its greedy assumption assumes visiting a node finalizes its shortest path',
      'It exceeds O(V^2) memory',
      'PriorityQueue cannot store negative integers'
    ],
    correctAnswerIndex: 1,
    explanation: 'Dijkstra greedily assumes once a vertex is extracted from the PriorityQueue, its distance cannot be reduced further; negative edges violate this assumption.'
  },

  // Java
  {
    id: 'q-j-1',
    documentId: 'doc-java-103',
    questionText: 'Where are object instances created with the \'new\' keyword stored in JVM memory?',
    options: ['Stack Memory', 'Heap Memory', 'Program Counter Register', 'Native Method Stack'],
    correctAnswerIndex: 1,
    explanation: 'All object instances and their member fields are allocated on the Heap and managed by the JVM Garbage Collector.'
  },
  {
    id: 'q-j-2',
    documentId: 'doc-java-103',
    questionText: 'At what collision threshold does a Java HashMap bucket convert from a LinkedList to a Red-Black Tree?',
    options: ['4 elements', '8 elements', '16 elements', '32 elements'],
    correctAnswerIndex: 1,
    explanation: 'In Java 8+, when a bucket\'s collisions exceed TREEIFY_THRESHOLD (8 elements) and total table capacity is at least 64, it treeifies to ensure O(log n) lookup.'
  },
  {
    id: 'q-j-3',
    documentId: 'doc-java-103',
    questionText: 'What major feature was introduced in Java 21 to revolutionize high-concurrency I/O?',
    options: ['Virtual Threads (Project Loom)', 'Generics', 'Lambda Expressions', 'Applets'],
    correctAnswerIndex: 0,
    explanation: 'Java 21 standardized Virtual Threads, allowing millions of lightweight threads to be scheduled by the JVM without 1:1 OS thread overhead.'
  },

  // Digital Electronics
  {
    id: 'q-de-1',
    documentId: 'doc-de-104',
    questionText: 'According to De Morgan\'s theorem, what is equivalent to (A • B)\'?',
    options: ['A\' • B\'', 'A\' + B\'', 'A + B', '(A + B)\''],
    correctAnswerIndex: 1,
    explanation: 'De Morgan\'s first theorem states the complement of a product equals the sum of the complements: (A • B)\' = A\' + B\'.'
  },
  {
    id: 'q-de-2',
    documentId: 'doc-de-104',
    questionText: 'What is the output state of a JK Flip-Flop on the next clock pulse when J = 1 and K = 1?',
    options: ['Set (Q=1)', 'Reset (Q=0)', 'Toggle (Q_next = Q\')', 'Invalid / Indeterminate'],
    correctAnswerIndex: 2,
    explanation: 'When both J and K are HIGH, the JK Flip-Flop toggles its current state to the opposite value.'
  },
  {
    id: 'q-de-3',
    documentId: 'doc-de-104',
    questionText: 'How many select lines are required for an 8-to-1 Multiplexer (MUX)?',
    options: ['2 select lines', '3 select lines', '4 select lines', '8 select lines'],
    correctAnswerIndex: 1,
    explanation: 'A multiplexer with 2^n inputs requires n select lines. For 8 inputs (2^3), exactly 3 select lines are required.'
  }
];
