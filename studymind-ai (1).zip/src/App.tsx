import React, { useState, useEffect } from 'react';
import { 
  BookOpen, 
  MessageSquare, 
  Layers, 
  HelpCircle, 
  Sparkles, 
  Loader2, 
  AlertCircle,
  Database
} from 'lucide-react';
import { StudyMaterial, FlashcardItem, QuizQuestion, QuizResult, StudyChatMessage, AppTab } from './types';
import { ApiService } from './services/api';
import { STARTER_MATERIALS, STARTER_FLASHCARDS, STARTER_QUIZZES } from './data/starterPacks';
import { calculateDeckMastery } from './domain/spacedRepetition';
import { Header } from './components/Header';
import { WorkspaceScreen } from './components/WorkspaceScreen';
import { AskAiScreen } from './components/AskAiScreen';
import { FlashcardsScreen } from './components/FlashcardsScreen';
import { QuizScreen } from './components/QuizScreen';
import { PasteNotesDialog } from './components/PasteNotesDialog';
import { ConceptExplanationModal } from './components/ConceptExplanationModal';
import { DatabaseModal } from './components/DatabaseModal';

export default function App() {
  const [currentTab, setCurrentTab] = useState<AppTab>('workspace');
  const [materials, setMaterials] = useState<StudyMaterial[]>([]);
  const [selectedMaterial, setSelectedMaterial] = useState<StudyMaterial | null>(null);
  const [flashcards, setFlashcards] = useState<FlashcardItem[]>([]);
  const [quizQuestions, setQuizQuestions] = useState<QuizQuestion[]>([]);
  const [quizResults, setQuizResults] = useState<QuizResult[]>([]);
  const [chatMessages, setChatMessages] = useState<StudyChatMessage[]>([]);
  
  // System & Loading State
  const [isLoading, setIsLoading] = useState(false);
  const [loadingMessage, setLoadingMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [geminiConfigured, setGeminiConfigured] = useState(true);

  // Modals
  const [isPasteDialogOpen, setIsPasteDialogOpen] = useState(false);
  const [isDatabaseModalOpen, setIsDatabaseModalOpen] = useState(false);
  const [conceptModalData, setConceptModalData] = useState<{ title: string; content: string } | null>(null);

  // Load database on initial mount
  useEffect(() => {
    loadDatabaseState();
  }, []);

  const loadDatabaseState = async () => {
    try {
      const health = await ApiService.getHealth();
      setGeminiConfigured(health.geminiConfigured);

      const loadedMaterials = await ApiService.getMaterials();
      setMaterials(loadedMaterials);

      const allCards = await ApiService.getFlashcards();
      setFlashcards(allCards);

      const allQuizResults = await ApiService.getQuizResults();
      setQuizResults(allQuizResults);

      // Do not force auto-select on initial load so the user sees the Upload First onboarding hub
    } catch (e: any) {
      console.error('Error bootstrapping database:', e);
      setMaterials(STARTER_MATERIALS);
      setFlashcards(STARTER_FLASHCARDS);
    }
  };

  const selectDocument = async (doc: StudyMaterial) => {
    setSelectedMaterial(doc);

    // Filter cards for this document
    const docCards = flashcards.filter(f => f.documentId === doc.id);
    if (docCards.length === 0) {
      const fetchedCards = await ApiService.getFlashcards(doc.id);
      setFlashcards(prev => [...prev.filter(f => f.documentId !== doc.id), ...fetchedCards]);
    }

    // Fetch quiz questions
    const fetchedQuiz = await ApiService.getQuizQuestions(doc.id);
    setQuizQuestions(fetchedQuiz);

    // Initial welcome chat message
    setChatMessages([
      {
        id: 'welcome-' + doc.id,
        text: `Hello! I am your AI study companion for **${doc.title}** (${doc.wordCount} words).\n\nAsk me any questions, generate exam flashcards, or take a practice quiz whenever you are ready!`,
        isUser: false,
        timestamp: Date.now(),
        documentTitle: doc.title,
      },
    ]);
  };

  const handleClearActiveMaterial = () => {
    setSelectedMaterial(null);
    setCurrentTab('workspace');
  };

  // Add uploaded or pasted document and trigger auto-generation pipeline in parallel
  const handleAddMaterial = async (title: string, content: string, subject: string) => {
    setIsLoading(true);
    setLoadingMessage(`Processing '${title}' into the AI study database...`);

    try {
      const newDoc = await ApiService.createMaterial(title, content, subject);
      setMaterials(prev => [newDoc, ...prev]);
      setSelectedMaterial(newDoc);

      setLoadingMessage(`Synthesizing executive summary, flashcards & quiz with AI...`);

      // Run AI generation in parallel for fast, non-blocking execution
      const [summaryResult, cardsResult, quizResult] = await Promise.allSettled([
        ApiService.generateSummary(newDoc.id, newDoc.title, newDoc.content),
        ApiService.generateFlashcards(newDoc.id, newDoc.title, newDoc.content, 6),
        ApiService.generateQuiz(newDoc.id, newDoc.title, newDoc.content, 5),
      ]);

      if (summaryResult.status === 'fulfilled') {
        newDoc.summary = summaryResult.value.summary;
        newDoc.keyTakeaways = summaryResult.value.keyTakeaways;
      }

      let generatedCardCount = 0;
      if (cardsResult.status === 'fulfilled') {
        const newCards = cardsResult.value.flashcards;
        generatedCardCount = newCards.length;
        setFlashcards(prev => [...newCards, ...prev]);
      }

      let generatedQuizCount = 0;
      if (quizResult.status === 'fulfilled') {
        const newQuiz = quizResult.value.questions;
        generatedQuizCount = newQuiz.length;
        setQuizQuestions(newQuiz);
      }

      // Initial welcome message
      setChatMessages([
        {
          id: 'welcome-' + newDoc.id,
          text: `Your material **${newDoc.title}** has been processed successfully!\n\n• **Word Count**: ${newDoc.wordCount}\n• **Est. Reading Time**: ${newDoc.readingTimeMinutes} mins\n• **Flashcards**: ${generatedCardCount} cards generated\n• **Practice Quiz**: ${generatedQuizCount} questions prepared\n\nAsk me any doubt or select a suggestion chip to get started!`,
          isUser: false,
          timestamp: Date.now(),
          documentTitle: newDoc.title,
        },
      ]);
    } catch (err: any) {
      console.error('Failed to create material:', err);
      setErrorMessage(err.message || 'Failed to process document');
    } finally {
      setIsLoading(false);
      setLoadingMessage('');
    }
  };

  const handleDeleteMaterial = async (id: string) => {
    try {
      await ApiService.deleteMaterial(id);
      const remaining = materials.filter(m => m.id !== id);
      setMaterials(remaining);
      setFlashcards(prev => prev.filter(f => f.documentId !== id));
      setQuizQuestions(prev => prev.filter(q => q.documentId !== id));

      if (selectedMaterial?.id === id) {
        if (remaining.length > 0) {
          selectDocument(remaining[0]);
        } else {
          setSelectedMaterial(null);
        }
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to delete document');
    }
  };

  const handleLoadSampleSubject = (subjectName: string) => {
    const match = STARTER_MATERIALS.find(m => m.subject.toLowerCase() === subjectName.toLowerCase()) || STARTER_MATERIALS[0];
    if (match) {
      // Check if already in materials
      if (!materials.some(m => m.id === match.id)) {
        setMaterials(prev => [match, ...prev]);
      }
      selectDocument(match);
    }
  };

  const handleGenerateSummary = async () => {
    if (!selectedMaterial) return;
    setIsLoading(true);
    setLoadingMessage(`Regenerating AI Executive Summary for '${selectedMaterial.title}'...`);
    try {
      const res = await ApiService.generateSummary(selectedMaterial.id, selectedMaterial.title, selectedMaterial.content);
      const updated = { ...selectedMaterial, summary: res.summary, keyTakeaways: res.keyTakeaways };
      setSelectedMaterial(updated);
      setMaterials(prev => prev.map(m => m.id === updated.id ? updated : m));
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to generate summary');
    } finally {
      setIsLoading(false);
      setLoadingMessage('');
    }
  };

  const handleAskDoubt = async (question: string) => {
    if (!selectedMaterial) return;
    const userMsg: StudyChatMessage = {
      id: 'msg-' + Date.now() + '-u',
      text: question,
      isUser: true,
      timestamp: Date.now(),
      documentTitle: selectedMaterial.title,
    };
    setChatMessages(prev => [...prev, userMsg]);

    setIsLoading(true);
    setLoadingMessage(`StudyMind AI is referencing '${selectedMaterial.title}'...`);

    try {
      const historyPairs = chatMessages.slice(-6).map(m => ({ text: m.text, isUser: m.isUser }));
      const res = await ApiService.askDoubt(
        selectedMaterial.id,
        selectedMaterial.title,
        selectedMaterial.content,
        question,
        historyPairs
      );

      const botMsg: StudyChatMessage = {
        id: 'msg-' + Date.now() + '-m',
        text: res.answer,
        isUser: false,
        timestamp: Date.now(),
        documentTitle: selectedMaterial.title,
      };
      setChatMessages(prev => [...prev, botMsg]);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to get an answer from Gemini');
    } finally {
      setIsLoading(false);
      setLoadingMessage('');
    }
  };

  const handleGenerateAiCards = async (count: number) => {
    if (!selectedMaterial) return;
    setIsLoading(true);
    setLoadingMessage(`Generating ${count} spaced-repetition flashcards with AI...`);
    try {
      const res = await ApiService.generateFlashcards(selectedMaterial.id, selectedMaterial.title, selectedMaterial.content, count);
      setFlashcards(prev => [...res.flashcards, ...prev]);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to generate flashcards');
    } finally {
      setIsLoading(false);
      setLoadingMessage('');
    }
  };

  const handleRateCard = async (cardId: string, rating: number) => {
    try {
      const res = await ApiService.reviewCard(cardId, rating);
      setFlashcards(prev => prev.map(c => c.id === cardId ? res.card : c));
    } catch (err) {
      console.error('Failed to save card rating:', err);
    }
  };

  const handleToggleBookmark = async (cardId: string) => {
    try {
      const updated = await ApiService.bookmarkCard(cardId);
      setFlashcards(prev => prev.map(c => c.id === cardId ? updated : c));
    } catch (err) {
      console.error('Failed to bookmark card:', err);
    }
  };

  const handleAddCustomCard = async (question: string, answer: string, topic: string, difficulty: 'Easy' | 'Medium' | 'Hard') => {
    if (!selectedMaterial) return;
    try {
      const newCard = await ApiService.createFlashcard(selectedMaterial.id, question, answer, topic, difficulty);
      setFlashcards(prev => [newCard, ...prev]);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to add card');
    }
  };

  const handleGenerateAiQuiz = async (count: number) => {
    if (!selectedMaterial) return;
    setIsLoading(true);
    setLoadingMessage(`Synthesizing ${count} rigorous practice exam questions with AI...`);
    try {
      const res = await ApiService.generateQuiz(selectedMaterial.id, selectedMaterial.title, selectedMaterial.content, count);
      setQuizQuestions(res.questions);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to generate quiz');
    } finally {
      setIsLoading(false);
      setLoadingMessage('');
    }
  };

  const handleSaveQuizResult = async (result: QuizResult) => {
    try {
      const saved = await ApiService.saveQuizResult(result);
      setQuizResults(prev => [saved, ...prev]);
    } catch (err) {
      console.error('Failed to persist quiz result:', err);
    }
  };

  const handleExplainSimply = async (concept: string) => {
    if (!selectedMaterial) return;
    setIsLoading(true);
    setLoadingMessage(`Generating intuitive analogy for '${concept}'...`);
    try {
      const res = await ApiService.explainConcept(concept, selectedMaterial.content, true);
      setConceptModalData({
        title: `ELI5 Analogy: ${concept}`,
        content: res.explanation,
      });
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to explain concept');
    } finally {
      setIsLoading(false);
      setLoadingMessage('');
    }
  };

  const handleResetDatabase = async () => {
    setIsLoading(true);
    setLoadingMessage('Resetting database to starter courses...');
    try {
      await ApiService.resetDatabase();
      await loadDatabaseState();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to reset database');
    } finally {
      setIsLoading(false);
      setLoadingMessage('');
    }
  };

  const handleImportDatabase = async (data: any) => {
    setIsLoading(true);
    setLoadingMessage('Importing database file...');
    try {
      await ApiService.importDatabase(data);
      await loadDatabaseState();
      setIsDatabaseModalOpen(false);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to import database');
    } finally {
      setIsLoading(false);
      setLoadingMessage('');
    }
  };

  const activeDocCards = selectedMaterial ? flashcards.filter(f => f.documentId === selectedMaterial.id) : [];
  const deckMastery = calculateDeckMastery(activeDocCards);

  return (
    <div className="min-h-screen bg-[#090b10] text-[#f5f6fa] flex flex-col selection:bg-[#7c4dff]/30">
      {/* Top Header */}
      <Header
        activeMaterial={selectedMaterial}
        geminiConfigured={geminiConfigured}
        onOpenDatabase={() => setIsDatabaseModalOpen(true)}
        onOpenUpload={() => setIsPasteDialogOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-4 py-5">
        {currentTab === 'workspace' && (
          <WorkspaceScreen
            materials={materials}
            activeMaterial={selectedMaterial}
            onSelectMaterial={selectDocument}
            onClearActiveMaterial={handleClearActiveMaterial}
            onAddMaterial={handleAddMaterial}
            onDeleteMaterial={handleDeleteMaterial}
            onLoadSampleSubject={handleLoadSampleSubject}
            onGenerateSummary={handleGenerateSummary}
            onOpenPasteDialog={() => setIsPasteDialogOpen(true)}
            onNavigateToChat={() => setCurrentTab('ask_ai')}
            onNavigateToFlashcards={() => setCurrentTab('flashcards')}
            onNavigateToQuiz={() => setCurrentTab('quiz')}
            onError={(msg) => setErrorMessage(msg)}
          />
        )}

        {currentTab === 'ask_ai' && (
          <AskAiScreen
            activeMaterial={selectedMaterial}
            chatMessages={chatMessages}
            isLoading={isLoading}
            onSendMessage={handleAskDoubt}
            onExplainSimply={handleExplainSimply}
            onNavigateToUpload={() => setCurrentTab('workspace')}
          />
        )}

        {currentTab === 'flashcards' && (
          <FlashcardsScreen
            activeMaterial={selectedMaterial}
            flashcards={activeDocCards}
            deckMasteryPercentage={deckMastery}
            isLoading={isLoading}
            onRateCard={handleRateCard}
            onToggleBookmark={handleToggleBookmark}
            onGenerateAiCards={handleGenerateAiCards}
            onAddCustomCard={handleAddCustomCard}
            onNavigateToUpload={() => setCurrentTab('workspace')}
          />
        )}

        {currentTab === 'quiz' && (
          <QuizScreen
            activeMaterial={selectedMaterial}
            quizQuestions={quizQuestions}
            isLoading={isLoading}
            onSaveQuizResult={handleSaveQuizResult}
            onGenerateAiQuiz={handleGenerateAiQuiz}
            onNavigateToUpload={() => setCurrentTab('workspace')}
          />
        )}
      </main>

      {/* Floating Bottom Navigation Bar */}
      <nav className="fixed bottom-0 inset-x-0 z-30 bg-[#121622]/95 backdrop-blur-md border-t border-[#262c42] py-2 px-4 shadow-2xl">
        <div className="max-w-md mx-auto grid grid-cols-4 gap-1">
          <button
            onClick={() => setCurrentTab('workspace')}
            className={`flex flex-col items-center justify-center py-1.5 px-2 rounded-2xl transition-all ${
              currentTab === 'workspace'
                ? 'text-[#9d72ff] bg-[#7c4dff]/15 font-bold'
                : 'text-[#9aa0a6] hover:text-[#f5f6fa]'
            }`}
          >
            <BookOpen className="w-5 h-5 mb-0.5" />
            <span className="text-[10px]">Workspace</span>
          </button>

          <button
            onClick={() => setCurrentTab('ask_ai')}
            className={`flex flex-col items-center justify-center py-1.5 px-2 rounded-2xl transition-all ${
              currentTab === 'ask_ai'
                ? 'text-[#9d72ff] bg-[#7c4dff]/15 font-bold'
                : 'text-[#9aa0a6] hover:text-[#f5f6fa]'
            }`}
          >
            <MessageSquare className="w-5 h-5 mb-0.5" />
            <span className="text-[10px]">Ask AI</span>
          </button>

          <button
            onClick={() => setCurrentTab('flashcards')}
            className={`flex flex-col items-center justify-center py-1.5 px-2 rounded-2xl transition-all ${
              currentTab === 'flashcards'
                ? 'text-[#9d72ff] bg-[#7c4dff]/15 font-bold'
                : 'text-[#9aa0a6] hover:text-[#f5f6fa]'
            }`}
          >
            <Layers className="w-5 h-5 mb-0.5" />
            <span className="text-[10px]">Flashcards</span>
          </button>

          <button
            onClick={() => setCurrentTab('quiz')}
            className={`flex flex-col items-center justify-center py-1.5 px-2 rounded-2xl transition-all ${
              currentTab === 'quiz'
                ? 'text-[#9d72ff] bg-[#7c4dff]/15 font-bold'
                : 'text-[#9aa0a6] hover:text-[#f5f6fa]'
            }`}
          >
            <HelpCircle className="w-5 h-5 mb-0.5" />
            <span className="text-[10px]">Quiz</span>
          </button>
        </div>
      </nav>

      {/* Global Loading Overlay */}
      {isLoading && loadingMessage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
          <div className="bg-[#151928] border-2 border-[#9d72ff]/50 rounded-3xl p-6 sm:p-8 max-w-sm w-full text-center shadow-2xl space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-[#7c4dff]/20 text-[#9d72ff] flex items-center justify-center mx-auto">
              <Loader2 className="w-6 h-6 animate-spin" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-[#f5f6fa]">StudyMind AI</h3>
              <p className="text-xs text-[#9aa0a6] mt-1 leading-relaxed">{loadingMessage}</p>
            </div>
          </div>
        </div>
      )}

      {/* Error Toast */}
      {errorMessage && (
        <div className="fixed top-16 right-4 z-50 max-w-md bg-[#ff7675]/20 border border-[#ff7675] text-[#f5f6fa] rounded-2xl p-4 shadow-xl flex items-start gap-3 animate-slideDown">
          <AlertCircle className="w-5 h-5 text-[#ff7675] shrink-0 mt-0.5" />
          <div className="flex-1 text-xs">{errorMessage}</div>
          <button
            onClick={() => setErrorMessage(null)}
            className="text-[#9aa0a6] hover:text-white text-xs font-bold"
          >
            ✕
          </button>
        </div>
      )}

      {/* Paste Notes Modal */}
      <PasteNotesDialog
        isOpen={isPasteDialogOpen}
        onClose={() => setIsPasteDialogOpen(false)}
        onSubmit={handleAddMaterial}
      />

      {/* Concept Explanation Dialog */}
      <ConceptExplanationModal
        title={conceptModalData?.title || null}
        content={conceptModalData?.content || null}
        onClose={() => setConceptModalData(null)}
      />

      {/* Database & Process Monitor Dialog */}
      <DatabaseModal
        isOpen={isDatabaseModalOpen}
        onClose={() => setIsDatabaseModalOpen(false)}
        materials={materials}
        flashcards={flashcards}
        quizResults={quizResults}
        geminiConfigured={geminiConfigured}
        onResetDatabase={handleResetDatabase}
        onImportDatabase={handleImportDatabase}
      />
    </div>
  );
}
