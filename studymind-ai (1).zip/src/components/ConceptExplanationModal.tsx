import React from 'react';
import { X, Lightbulb, Check } from 'lucide-react';

interface ConceptExplanationModalProps {
  title: string | null;
  content: string | null;
  onClose: () => void;
}

export const ConceptExplanationModal: React.FC<ConceptExplanationModalProps> = ({
  title,
  content,
  onClose,
}) => {
  if (!content) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fadeIn">
      <div className="bg-[#151928] border border-[#7c4dff]/50 rounded-2xl w-full max-w-lg p-6 shadow-2xl relative max-h-[85vh] flex flex-col">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-[#9aa0a6] hover:text-white p-1 rounded-lg hover:bg-[#1a1f30] transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-[#00d2d3]/15 flex items-center justify-center text-[#00d2d3]">
            <Lightbulb className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-[#9d72ff]">{title || 'Concept Breakdown'}</h3>
            <p className="text-[11px] text-[#9aa0a6]">StudyMind AI Explanation</p>
          </div>
        </div>

        <div className="overflow-y-auto pr-2 text-sm text-[#f5f6fa] leading-relaxed whitespace-pre-wrap flex-1 my-2">
          {content}
        </div>

        <div className="flex justify-end pt-4 border-t border-[#262c42]">
          <button
            onClick={onClose}
            className="flex items-center gap-2 px-5 py-2 rounded-xl bg-[#7c4dff] hover:bg-[#6c3fe0] text-white text-xs font-semibold shadow-md shadow-[#7c4dff]/25 transition-all"
          >
            <Check className="w-3.5 h-3.5" />
            Got It
          </button>
        </div>
      </div>
    </div>
  );
};
