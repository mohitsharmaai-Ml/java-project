import React from 'react';
import { Database, Plus, Sparkles, CheckCircle2, AlertCircle } from 'lucide-react';
import { StudyMaterial } from '../types';

interface HeaderProps {
  activeMaterial: StudyMaterial | null;
  geminiConfigured: boolean;
  onOpenDatabase: () => void;
  onOpenUpload: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeMaterial,
  geminiConfigured,
  onOpenDatabase,
  onOpenUpload,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-[#121622]/90 backdrop-blur-md border-b border-[#262c42] px-4 py-3">
      <div className="max-w-6xl mx-auto flex items-center justify-between">
        {/* Brand & Logo */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl overflow-hidden bg-gradient-to-tr from-[#7c4dff] to-[#9d72ff] p-0.5 shadow-lg shadow-[#7c4dff]/20">
            <img
              src="/studymind_logo.png"
              alt="StudyMind Logo"
              className="w-full h-full object-cover rounded-[10px]"
              onError={(e) => {
                // Fallback icon if logo image fails
                (e.target as HTMLElement).style.display = 'none';
              }}
            />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg md:text-xl font-bold text-[#f5f6fa] tracking-tight">
                StudyMind <span className="text-[#9d72ff]">AI</span>
              </h1>
              {geminiConfigured ? (
                <span className="hidden sm:inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full bg-[#00b894]/15 text-[#00b894] border border-[#00b894]/30">
                  <Sparkles className="w-2.5 h-2.5" />
                  Gemini Active
                </span>
              ) : (
                <span className="hidden sm:inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full bg-[#fdcb6e]/15 text-[#fdcb6e] border border-[#fdcb6e]/30">
                  <Sparkles className="w-2.5 h-2.5" />
                  Smart Offline Mode
                </span>
              )}
            </div>
            <p className="text-[11px] text-[#9aa0a6] hidden sm:block">
              AI-Powered Student Learning Platform
            </p>
          </div>
        </div>

        {/* Right Actions: Database Monitor & Add Material */}
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenDatabase}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#1a1f30] hover:bg-[#262c42] text-[#9aa0a6] hover:text-[#f5f6fa] border border-[#262c42] text-xs font-medium transition-colors shadow-sm"
            title="Database & Process Monitor"
          >
            <Database className="w-3.5 h-3.5 text-[#00d2d3]" />
            <span className="hidden md:inline">Database & Process</span>
            <span className="md:hidden">DB</span>
          </button>

          <button
            onClick={onOpenUpload}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-[#7c4dff] to-[#9d72ff] hover:from-[#6c3fe0] hover:to-[#8c61f0] text-white text-xs font-semibold shadow-md shadow-[#7c4dff]/25 transition-all active:scale-95"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Notes</span>
          </button>
        </div>
      </div>
    </header>
  );
};
