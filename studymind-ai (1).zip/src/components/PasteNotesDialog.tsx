import React, { useState } from 'react';
import { X, Sparkles, BookOpen, FileText } from 'lucide-react';

interface PasteNotesDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (title: string, content: string, subject: string) => void;
}

export const PasteNotesDialog: React.FC<PasteNotesDialogProps> = ({
  isOpen,
  onClose,
  onSubmit,
}) => {
  const [title, setTitle] = useState('');
  const [subject, setSubject] = useState('Computer Science');
  const [content, setContent] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) return;
    onSubmit(
      title.trim() || 'Uploaded Notes',
      content.trim(),
      subject.trim() || 'General'
    );
    setTitle('');
    setContent('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
      <div className="bg-[#121622] border border-[#262c42] rounded-2xl w-full max-w-lg p-6 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-[#9aa0a6] hover:text-white p-1 rounded-lg hover:bg-[#1a1f30] transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2.5 mb-4">
          <div className="w-9 h-9 rounded-xl bg-[#7c4dff]/20 flex items-center justify-center text-[#9d72ff]">
            <FileText className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-[#f5f6fa]">Paste Notes / Slide Text</h2>
            <p className="text-xs text-[#9aa0a6]">Import your study material into the AI database</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-[#9aa0a6] mb-1.5">
              Topic / Document Title
            </label>
            <input
              type="text"
              placeholder="e.g. Chapter 4: Graph Algorithms"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full bg-[#1a1f30] border border-[#262c42] focus:border-[#9d72ff] rounded-xl px-3.5 py-2 text-sm text-[#f5f6fa] placeholder-[#9aa0a6]/50 outline-none transition-colors"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#9aa0a6] mb-1.5">
              Subject / Course
            </label>
            <input
              type="text"
              placeholder="e.g. DSA, Maths, Java, Digital Electronics"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full bg-[#1a1f30] border border-[#262c42] focus:border-[#9d72ff] rounded-xl px-3.5 py-2 text-sm text-[#f5f6fa] placeholder-[#9aa0a6]/50 outline-none transition-colors"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#9aa0a6] mb-1.5">
              Notes Content / Extracted Text
            </label>
            <textarea
              required
              rows={6}
              placeholder="Paste lecture slides, textbook passages, or key revision notes here..."
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="w-full bg-[#1a1f30] border border-[#262c42] focus:border-[#9d72ff] rounded-xl p-3.5 text-sm text-[#f5f6fa] placeholder-[#9aa0a6]/50 outline-none resize-none transition-colors"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-[#9aa0a6] hover:text-white rounded-xl hover:bg-[#1a1f30] transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!content.trim()}
              className="flex items-center gap-2 px-5 py-2 rounded-xl bg-gradient-to-r from-[#7c4dff] to-[#9d72ff] text-white text-xs font-semibold shadow-md shadow-[#7c4dff]/25 hover:opacity-95 transition-all disabled:opacity-50"
            >
              <Sparkles className="w-3.5 h-3.5" />
              Process & Create AI Deck
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
