import React, { useState, useRef, useEffect } from 'react';
import { 
  Sparkles, 
  Send, 
  Copy, 
  Check, 
  Lightbulb, 
  BookOpen, 
  User, 
  Bot, 
  Upload, 
  HelpCircle 
} from 'lucide-react';
import { StudyChatMessage, StudyMaterial } from '../types';

interface AskAiScreenProps {
  activeMaterial: StudyMaterial | null;
  chatMessages: StudyChatMessage[];
  isLoading: boolean;
  onSendMessage: (question: string) => void;
  onExplainSimply: (concept: string) => void;
  onNavigateToUpload: () => void;
}

export const AskAiScreen: React.FC<AskAiScreenProps> = ({
  activeMaterial,
  chatMessages,
  isLoading,
  onSendMessage,
  onExplainSimply,
  onNavigateToUpload,
}) => {
  const [inputText, setInputText] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const quickChips = [
    "Explain like I'm 5",
    'Key exam questions likely to be asked',
    'Step-by-step practical example',
    'What are the major pitfalls/mistakes?',
    'Summary in 3 bullet points',
  ];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages, isLoading]);

  const handleSend = (text: string) => {
    if (!text.trim() || isLoading) return;
    onSendMessage(text.trim());
    setInputText('');
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  if (!activeMaterial) {
    return (
      <div className="flex flex-col items-center justify-center p-8 text-center max-w-md mx-auto my-12 bg-[#151928] border-2 border-[#9d72ff]/40 rounded-3xl shadow-xl">
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-[#7c4dff] to-[#9d72ff] flex items-center justify-center text-white mb-4 shadow-lg shadow-[#7c4dff]/25">
          <Sparkles className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold text-[#f5f6fa]">AI Study Assistant</h2>
        <p className="text-xs text-[#9aa0a6] mt-2 leading-relaxed">
          To start asking questions, resolving doubts, and clarifying difficult concepts, please upload a document or select a starter pack first.
        </p>
        <button
          onClick={onNavigateToUpload}
          className="mt-6 px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#7c4dff] to-[#9d72ff] text-white text-xs font-semibold shadow-md shadow-[#7c4dff]/25 hover:opacity-95 transition-all"
        >
          Go to Workspace / Upload
        </button>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-[calc(100vh-140px)] max-w-4xl mx-auto animate-fadeIn">
      {/* Grounded Document Banner */}
      <div className="bg-[#151928] border border-[#262c42] rounded-2xl p-3.5 flex items-center justify-between mb-3 shadow-sm">
        <div className="flex items-center gap-2.5 overflow-hidden">
          <div className="w-8 h-8 rounded-lg bg-[#7c4dff]/20 flex items-center justify-center text-[#9d72ff] shrink-0">
            <BookOpen className="w-4 h-4" />
          </div>
          <div className="overflow-hidden">
            <div className="text-[10px] font-bold tracking-wider text-[#9d72ff] uppercase">
              DOCUMENT-GROUNDED ASSISTANT
            </div>
            <div className="text-xs font-bold text-[#f5f6fa] truncate">
              {activeMaterial.title}
            </div>
          </div>
        </div>
        <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-[#00d2d3]/15 text-[#00d2d3] border border-[#00d2d3]/30 shrink-0">
          {activeMaterial.subject}
        </span>
      </div>

      {/* Suggestion Chips */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {quickChips.map((chip, idx) => (
          <button
            key={idx}
            onClick={() => handleSend(chip)}
            disabled={isLoading}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#151928] hover:bg-[#1a1f30] border border-[#262c42] hover:border-[#7c4dff]/50 text-xs text-[#9aa0a6] hover:text-[#f5f6fa] whitespace-nowrap transition-colors shrink-0 disabled:opacity-50"
          >
            <Sparkles className="w-3 h-3 text-[#9d72ff]" />
            <span>{chip}</span>
          </button>
        ))}
      </div>

      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto space-y-4 py-3 pr-1">
        {chatMessages.length === 0 ? (
          <div className="text-center py-16 space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-[#1a1f30] text-[#9d72ff] flex items-center justify-center mx-auto">
              <Bot className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-bold text-[#f5f6fa]">Ask Any Doubt</h3>
            <p className="text-xs text-[#9aa0a6] max-w-sm mx-auto">
              I have thoroughly analyzed <strong className="text-white">"{activeMaterial.title}"</strong>. Ask me for exam questions, code walkthroughs, mathematical proofs, or step-by-step explanations!
            </p>
          </div>
        ) : (
          chatMessages.map((msg) => (
            <div
              key={msg.id}
              className={`flex gap-3 ${msg.isUser ? 'justify-end' : 'justify-start'}`}
            >
              {!msg.isUser && (
                <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-[#7c4dff] to-[#9d72ff] flex items-center justify-center text-white shrink-0 mt-0.5 shadow-md shadow-[#7c4dff]/20">
                  <Sparkles className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-[85%] rounded-2xl p-4 space-y-2 text-xs sm:text-sm leading-relaxed ${
                  msg.isUser
                    ? 'bg-[#7c4dff] text-white rounded-tr-none shadow-md shadow-[#7c4dff]/20'
                    : 'bg-[#151928] text-[#f5f6fa] border border-[#262c42] rounded-tl-none shadow-sm'
                }`}
              >
                <div className="whitespace-pre-wrap">{msg.text}</div>

                {!msg.isUser && (
                  <div className="flex items-center gap-2 pt-2 border-t border-[#262c42]/60">
                    <button
                      onClick={() => handleCopy(msg.id, msg.text)}
                      className="flex items-center gap-1 text-[11px] text-[#9aa0a6] hover:text-[#00d2d3] transition-colors"
                    >
                      {copiedId === msg.id ? (
                        <>
                          <Check className="w-3 h-3 text-[#00b894]" />
                          <span className="text-[#00b894]">Copied!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span>Copy</span>
                        </>
                      )}
                    </button>

                    <button
                      onClick={() => onExplainSimply(msg.text.slice(0, 90))}
                      className="flex items-center gap-1 text-[11px] text-[#9aa0a6] hover:text-[#9d72ff] transition-colors ml-2"
                    >
                      <Lightbulb className="w-3 h-3 text-[#fdcb6e]" />
                      <span>Explain Simply</span>
                    </button>
                  </div>
                )}
              </div>

              {msg.isUser && (
                <div className="w-8 h-8 rounded-xl bg-[#1a1f30] border border-[#262c42] flex items-center justify-center text-[#9aa0a6] shrink-0 mt-0.5">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          ))
        )}

        {isLoading && (
          <div className="flex gap-3 justify-start animate-pulse">
            <div className="w-8 h-8 rounded-xl bg-[#7c4dff] flex items-center justify-center text-white shrink-0">
              <Sparkles className="w-4 h-4 animate-spin" />
            </div>
            <div className="bg-[#151928] border border-[#262c42] rounded-2xl rounded-tl-none p-4 text-xs text-[#9aa0a6] flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#9d72ff] animate-ping" />
              StudyMind AI is reviewing '{activeMaterial.title}'...
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Box */}
      <div className="pt-2">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend(inputText);
          }}
          className="flex items-center gap-2 bg-[#151928] border border-[#262c42] focus-within:border-[#9d72ff] rounded-2xl p-2 transition-colors shadow-lg"
        >
          <input
            type="text"
            placeholder="Ask any question on this subject..."
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            disabled={isLoading}
            className="flex-1 bg-transparent px-3 py-1.5 text-xs sm:text-sm text-[#f5f6fa] placeholder-[#9aa0a6]/50 outline-none"
          />
          <button
            type="submit"
            disabled={!inputText.trim() || isLoading}
            className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#7c4dff] to-[#9d72ff] flex items-center justify-center text-white shadow-md shadow-[#7c4dff]/25 hover:opacity-95 transition-all disabled:opacity-30 active:scale-95"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
