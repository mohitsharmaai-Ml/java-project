import React, { useState } from 'react';
import { X, Database, RefreshCw, Download, Upload, Trash2, CheckCircle2, FileText, Layers, Award, ShieldCheck } from 'lucide-react';
import { StudyMaterial, FlashcardItem, QuizResult } from '../types';

interface DatabaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  materials: StudyMaterial[];
  flashcards: FlashcardItem[];
  quizResults: QuizResult[];
  geminiConfigured: boolean;
  onResetDatabase: () => void;
  onImportDatabase: (data: any) => void;
}

export const DatabaseModal: React.FC<DatabaseModalProps> = ({
  isOpen,
  onClose,
  materials,
  flashcards,
  quizResults,
  geminiConfigured,
  onResetDatabase,
  onImportDatabase,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'overview' | 'quiz_history' | 'raw_data'>('overview');
  const [copiedStatus, setCopiedStatus] = useState(false);
  const [modalMessage, setModalMessage] = useState<string | null>(null);
  const [confirmingReset, setConfirmingReset] = useState(false);

  if (!isOpen) return null;

  const handleExport = () => {
    const data = {
      materials,
      flashcards,
      quizResults,
      exportedAt: new Date().toISOString(),
      platform: 'StudyMind AI',
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `studymind_database_backup_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleFileImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const json = JSON.parse(event.target?.result as string);
        onImportDatabase(json);
        setModalMessage('Database imported successfully!');
        setTimeout(() => setModalMessage(null), 3000);
      } catch (err) {
        setModalMessage('Failed to parse database file. Ensure it is valid JSON.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fadeIn">
      <div className="bg-[#121622] border border-[#262c42] rounded-2xl w-full max-w-3xl max-h-[90vh] shadow-2xl flex flex-col relative overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-[#262c42] flex items-center justify-between bg-[#151928]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#00d2d3]/15 flex items-center justify-center text-[#00d2d3]">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-[#f5f6fa] flex items-center gap-2">
                Database & Process Monitor
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-[#00b894]/15 text-[#00b894] border border-[#00b894]/30">
                  Healthy & Synchronized
                </span>
              </h2>
              <p className="text-xs text-[#9aa0a6]">
                Persistent Local Storage + Server JSON Store ({materials.length} Documents, {flashcards.length} Cards)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-[#9aa0a6] hover:text-white p-1 rounded-lg hover:bg-[#1a1f30] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Sub Navigation */}
        <div className="flex border-b border-[#262c42] bg-[#121622] px-5 gap-6 text-xs font-semibold">
          <button
            onClick={() => setActiveSubTab('overview')}
            className={`py-3 border-b-2 transition-colors ${
              activeSubTab === 'overview'
                ? 'border-[#9d72ff] text-[#9d72ff]'
                : 'border-transparent text-[#9aa0a6] hover:text-[#f5f6fa]'
            }`}
          >
            Storage & Health Overview
          </button>
          <button
            onClick={() => setActiveSubTab('quiz_history')}
            className={`py-3 border-b-2 transition-colors ${
              activeSubTab === 'quiz_history'
                ? 'border-[#9d72ff] text-[#9d72ff]'
                : 'border-transparent text-[#9aa0a6] hover:text-[#f5f6fa]'
            }`}
          >
            Exam & Assessment History ({quizResults.length})
          </button>
          <button
            onClick={() => setActiveSubTab('raw_data')}
            className={`py-3 border-b-2 transition-colors ${
              activeSubTab === 'raw_data'
                ? 'border-[#9d72ff] text-[#9d72ff]'
                : 'border-transparent text-[#9aa0a6] hover:text-[#f5f6fa]'
            }`}
          >
            Backup & JSON State
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {modalMessage && (
            <div className="p-3 rounded-xl bg-[#7c4dff]/20 border border-[#7c4dff] text-xs font-semibold text-[#f5f6fa] text-center animate-fadeIn">
              {modalMessage}
            </div>
          )}
          {activeSubTab === 'overview' && (
            <div className="space-y-5">
              {/* Stat Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="bg-[#151928] border border-[#262c42] rounded-xl p-4 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-[#7c4dff]/20 flex items-center justify-center text-[#9d72ff]">
                    <FileText className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xl font-bold text-[#f5f6fa]">{materials.length}</div>
                    <div className="text-[11px] text-[#9aa0a6]">Study Materials</div>
                  </div>
                </div>

                <div className="bg-[#151928] border border-[#262c42] rounded-xl p-4 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-[#00d2d3]/20 flex items-center justify-center text-[#00d2d3]">
                    <Layers className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xl font-bold text-[#f5f6fa]">{flashcards.length}</div>
                    <div className="text-[11px] text-[#9aa0a6]">Recall Cards Tracked</div>
                  </div>
                </div>

                <div className="bg-[#151928] border border-[#262c42] rounded-xl p-4 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-[#00b894]/20 flex items-center justify-center text-[#00b894]">
                    <Award className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xl font-bold text-[#f5f6fa]">{quizResults.length}</div>
                    <div className="text-[11px] text-[#9aa0a6]">Quiz Attempts Saved</div>
                  </div>
                </div>
              </div>

              {/* Process Architecture Status */}
              <div className="bg-[#151928] border border-[#262c42] rounded-xl p-5 space-y-3">
                <h3 className="text-xs font-bold uppercase tracking-wider text-[#9d72ff]">
                  Pipeline Architecture & Health
                </h3>
                <div className="space-y-2 text-xs">
                  <div className="flex items-center justify-between p-2.5 rounded-lg bg-[#1a1f30]">
                    <div className="flex items-center gap-2 text-[#f5f6fa]">
                      <ShieldCheck className="w-4 h-4 text-[#00b894]" />
                      <span>Persistent File Storage (JSON Database)</span>
                    </div>
                    <span className="text-[#00b894] font-semibold">Active & Syncing</span>
                  </div>

                  <div className="flex items-center justify-between p-2.5 rounded-lg bg-[#1a1f30]">
                    <div className="flex items-center gap-2 text-[#f5f6fa]">
                      <ShieldCheck className="w-4 h-4 text-[#00b894]" />
                      <span>Client Indexed Cache (Offline-First)</span>
                    </div>
                    <span className="text-[#00b894] font-semibold">Ready</span>
                  </div>

                  <div className="flex items-center justify-between p-2.5 rounded-lg bg-[#1a1f30]">
                    <div className="flex items-center gap-2 text-[#f5f6fa]">
                      <ShieldCheck className="w-4 h-4 text-[#7c4dff]" />
                      <span>AI Model Engine</span>
                    </div>
                    <span className="text-[#9d72ff] font-semibold">
                      {geminiConfigured ? 'Gemini 3.8 Flash (Active)' : 'Adaptive Heuristic Pipeline'}
                    </span>
                  </div>

                  <div className="flex items-center justify-between p-2.5 rounded-lg bg-[#1a1f30]">
                    <div className="flex items-center gap-2 text-[#f5f6fa]">
                      <ShieldCheck className="w-4 h-4 text-[#00d2d3]" />
                      <span>Spaced Repetition Algorithm</span>
                    </div>
                    <span className="text-[#00d2d3] font-semibold">SuperMemo-2 (SM-2)</span>
                  </div>
                </div>
              </div>

              {/* Quick Actions */}
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  onClick={handleExport}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#1a1f30] hover:bg-[#262c42] text-[#f5f6fa] border border-[#262c42] text-xs font-medium transition-colors"
                >
                  <Download className="w-3.5 h-3.5 text-[#00d2d3]" />
                  Export Database Backup (.json)
                </button>

                <label className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#1a1f30] hover:bg-[#262c42] text-[#f5f6fa] border border-[#262c42] text-xs font-medium cursor-pointer transition-colors">
                  <Upload className="w-3.5 h-3.5 text-[#9d72ff]" />
                  Import Backup
                  <input type="file" accept=".json" onChange={handleFileImport} className="hidden" />
                </label>

                {confirmingReset ? (
                  <div className="flex items-center gap-2 ml-auto">
                    <span className="text-[11px] text-[#ff7675]">Restore default packs?</span>
                    <button
                      onClick={() => {
                        onResetDatabase();
                        setConfirmingReset(false);
                        setModalMessage('Database reset to defaults.');
                        setTimeout(() => setModalMessage(null), 3000);
                      }}
                      className="px-3 py-1.5 rounded-xl bg-[#ff7675] text-white text-xs font-bold shadow-md shadow-[#ff7675]/30 hover:opacity-95"
                    >
                      Confirm
                    </button>
                    <button
                      onClick={() => setConfirmingReset(false)}
                      className="px-2 py-1.5 rounded-xl text-xs text-[#9aa0a6] hover:text-white"
                    >
                      Cancel
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setConfirmingReset(true)}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#ff7675]/10 hover:bg-[#ff7675]/20 text-[#ff7675] border border-[#ff7675]/30 text-xs font-medium transition-colors ml-auto"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    Reset to Starter Packs
                  </button>
                )}
              </div>
            </div>
          )}

          {activeSubTab === 'quiz_history' && (
            <div className="space-y-3">
              {quizResults.length === 0 ? (
                <div className="text-center py-10 bg-[#151928] rounded-xl border border-[#262c42]">
                  <Award className="w-10 h-10 text-[#9aa0a6] mx-auto mb-2 opacity-50" />
                  <p className="text-sm font-semibold text-[#f5f6fa]">No Quizzes Taken Yet</p>
                  <p className="text-xs text-[#9aa0a6] mt-1">Complete practice exams in the Quiz tab to view scorecards here.</p>
                </div>
              ) : (
                <div className="space-y-2.5">
                  {quizResults.map((result, idx) => (
                    <div
                      key={result.id || idx}
                      className="bg-[#151928] border border-[#262c42] rounded-xl p-4 flex items-center justify-between"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold text-[#f5f6fa]">
                            {result.documentTitle || 'Course Exam'}
                          </span>
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                              result.scorePercentage >= 80
                                ? 'bg-[#00b894]/20 text-[#00b894]'
                                : result.scorePercentage >= 60
                                ? 'bg-[#fdcb6e]/20 text-[#fdcb6e]'
                                : 'bg-[#ff7675]/20 text-[#ff7675]'
                            }`}
                          >
                            Grade {result.gradeLetter}
                          </span>
                        </div>
                        <p className="text-xs text-[#9aa0a6]">{result.feedbackMessage}</p>
                        <div className="text-[10px] text-[#9aa0a6]/70">
                          {result.timestamp ? new Date(result.timestamp).toLocaleDateString() : 'Recent'} • {result.correctAnswers} / {result.totalQuestions} Correct
                        </div>
                      </div>

                      <div className="text-right pl-4">
                        <div className="text-2xl font-black text-[#00d2d3]">
                          {result.scorePercentage}%
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeSubTab === 'raw_data' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-[#9aa0a6]">Live JSON Database snapshot:</span>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(JSON.stringify({ materials, flashcards, quizResults }, null, 2));
                    setCopiedStatus(true);
                    setTimeout(() => setCopiedStatus(false), 2000);
                  }}
                  className="text-xs text-[#9d72ff] hover:underline"
                >
                  {copiedStatus ? 'Copied to Clipboard!' : 'Copy JSON'}
                </button>
              </div>
              <pre className="bg-[#090b10] border border-[#262c42] rounded-xl p-4 text-[11px] font-mono text-[#00d2d3] max-h-72 overflow-auto">
                {JSON.stringify({ materials, flashcards, quizResults }, null, 2)}
              </pre>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-[#262c42] bg-[#151928] flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-[#1a1f30] hover:bg-[#262c42] text-white text-xs font-semibold transition-colors"
          >
            Close Monitor
          </button>
        </div>
      </div>
    </div>
  );
};
