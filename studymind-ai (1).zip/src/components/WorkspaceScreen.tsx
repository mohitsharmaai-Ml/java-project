import React, { useState } from 'react';
import { 
  CloudUpload, 
  FileText, 
  Sparkles, 
  BookOpen, 
  CheckCircle2, 
  Clock, 
  ChevronDown, 
  ChevronUp, 
  MessageSquare, 
  Layers, 
  HelpCircle, 
  Trash2, 
  Plus, 
  RefreshCw,
  ArrowLeftRight
} from 'lucide-react';
import { StudyMaterial } from '../types';
import { ApiService } from '../services/api';

interface WorkspaceScreenProps {
  materials: StudyMaterial[];
  activeMaterial: StudyMaterial | null;
  onSelectMaterial: (material: StudyMaterial) => void;
  onClearActiveMaterial: () => void;
  onAddMaterial: (title: string, content: string, subject: string) => void;
  onDeleteMaterial: (id: string) => void;
  onLoadSampleSubject: (subject: string) => void;
  onGenerateSummary: () => void;
  onOpenPasteDialog: () => void;
  onNavigateToChat: () => void;
  onNavigateToFlashcards: () => void;
  onNavigateToQuiz: () => void;
  onError?: (msg: string) => void;
}

export const WorkspaceScreen: React.FC<WorkspaceScreenProps> = ({
  materials,
  activeMaterial,
  onSelectMaterial,
  onClearActiveMaterial,
  onAddMaterial,
  onDeleteMaterial,
  onLoadSampleSubject,
  onGenerateSummary,
  onOpenPasteDialog,
  onNavigateToChat,
  onNavigateToFlashcards,
  onNavigateToQuiz,
  onError,
}) => {
  const [isFullContentExpanded, setIsFullContentExpanded] = useState(false);
  const [isExtractingFile, setIsExtractingFile] = useState(false);

  const starterSubjects = ['Maths', 'DSA', 'Java', 'Digital Electronics'];

  // Handle local PDF or Text document file picking via API
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsExtractingFile(true);
    const cleanFileName = file.name.replace(/\.[^/.]+$/, '');

    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const resultString = reader.result as string;
        const base64Data = resultString.split(',')[1] || '';

        const extracted = await ApiService.extractDocument(base64Data, file.name);
        if (extracted && extracted.text && extracted.text.length >= 10) {
          onAddMaterial(cleanFileName, extracted.text, 'Document Upload');
        } else {
          onError?.('Could not extract text from document. Please paste the notes text directly.');
        }
      } catch (err: any) {
        console.error('File parsing error:', err);
        onError?.('Error reading document: ' + (err.message || 'Unknown error'));
      } finally {
        setIsExtractingFile(false);
        e.target.value = '';
      }
    };

    reader.onerror = () => {
      setIsExtractingFile(false);
      onError?.('Failed to read file from disk');
      e.target.value = '';
    };

    reader.readAsDataURL(file);
  };

  return (
    <div className="space-y-6 pb-20 animate-fadeIn">
      {/* 1. ONBOARDING EMPTY STATE: When NO document is currently active */}
      {!activeMaterial ? (
        <div className="space-y-6">
          <div className="bg-[#151928] border-2 border-[#9d72ff]/40 rounded-3xl p-8 sm:p-10 text-center shadow-xl relative overflow-hidden">
            <div className="absolute -right-16 -top-16 w-56 h-56 bg-[#7c4dff]/15 rounded-full blur-3xl pointer-events-none" />
            
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-[#7c4dff] to-[#9d72ff] mx-auto flex items-center justify-center text-white shadow-lg shadow-[#7c4dff]/30 mb-5">
              <CloudUpload className="w-8 h-8" />
            </div>

            <h2 className="text-xl sm:text-2xl font-bold text-[#f5f6fa] tracking-tight">
              Upload Your Study Material
            </h2>
            <p className="text-xs sm:text-sm text-[#9aa0a6] max-w-lg mx-auto mt-2 leading-relaxed">
              Upload your PDF, lecture slides, or paste notes. StudyMind AI will parse your material and generate document-grounded doubt solving, active recall flashcards, and practice quizzes.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mt-8 max-w-md mx-auto">
              {/* Native file upload */}
              <label className="w-full sm:w-auto flex-1 flex items-center justify-center gap-2 px-5 py-3 rounded-2xl bg-[#7c4dff] hover:bg-[#6c3fe0] text-white text-xs sm:text-sm font-semibold shadow-md shadow-[#7c4dff]/25 cursor-pointer transition-all active:scale-95">
                <FileText className="w-4 h-4" />
                <span>{isExtractingFile ? 'Extracting Text...' : 'Choose PDF / Text File'}</span>
                <input
                  type="file"
                  accept=".pdf,.txt,.md,.json,.csv"
                  onChange={handleFileUpload}
                  disabled={isExtractingFile}
                  className="hidden"
                />
              </label>

              {/* Paste notes button */}
              <button
                onClick={onOpenPasteDialog}
                className="w-full sm:w-auto flex-1 flex items-center justify-center gap-2 px-5 py-3 rounded-2xl bg-[#1a1f30] hover:bg-[#262c42] text-[#f5f6fa] border border-[#262c42] text-xs sm:text-sm font-semibold transition-all active:scale-95"
              >
                <Sparkles className="w-4 h-4 text-[#00d2d3]" />
                <span>Paste Notes Text</span>
              </button>
            </div>
          </div>

          {/* Quick Curated Starter Subjects */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#9aa0a6]">
              Or Learn With A Curated Subject Pack:
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {starterSubjects.map((subj) => (
                <button
                  key={subj}
                  onClick={() => onLoadSampleSubject(subj)}
                  className="flex items-center gap-2.5 p-3.5 rounded-2xl bg-[#151928] hover:bg-[#1a1f30] border border-[#262c42] hover:border-[#7c4dff]/50 text-left transition-all group active:scale-95"
                >
                  <div className="w-8 h-8 rounded-xl bg-[#7c4dff]/15 flex items-center justify-center text-[#9d72ff] group-hover:scale-110 transition-transform">
                    <BookOpen className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-[#f5f6fa]">{subj}</div>
                    <div className="text-[10px] text-[#9aa0a6]">Preloaded Pack</div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* If materials already exist in library, display them */}
          {materials.length > 0 && (
            <div className="space-y-3 pt-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#9aa0a6]">
                Existing Saved Materials ({materials.length})
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {materials.map((doc) => (
                  <div
                    key={doc.id}
                    onClick={() => onSelectMaterial(doc)}
                    className="flex items-center justify-between p-4 rounded-2xl border border-[#262c42] bg-[#151928] hover:border-[#7c4dff]/50 cursor-pointer transition-all"
                  >
                    <div className="flex items-center gap-3 overflow-hidden">
                      <div className="w-10 h-10 rounded-xl bg-[#1a1f30] text-[#9d72ff] flex items-center justify-center shrink-0">
                        <BookOpen className="w-5 h-5" />
                      </div>
                      <div className="overflow-hidden">
                        <div className="text-xs font-bold text-[#f5f6fa] truncate">{doc.title}</div>
                        <div className="text-[11px] text-[#9aa0a6] flex items-center gap-2 mt-0.5">
                          <span>{doc.subject}</span>
                          <span>•</span>
                          <span>{doc.wordCount} words</span>
                        </div>
                      </div>
                    </div>
                    <span className="text-xs text-[#9d72ff] font-semibold shrink-0">Open</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      ) : (
        /* 2. ACTIVE MATERIAL STATE: Document Loaded & Tools Ready */
        <div className="space-y-5">
          {/* Active Document Card */}
          <div className="bg-[#151928] border-2 border-[#9d72ff]/40 rounded-3xl p-6 shadow-xl relative overflow-hidden">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-bold px-3 py-1 rounded-full bg-[#7c4dff]/20 text-[#9d72ff] border border-[#7c4dff]/40 uppercase tracking-wide">
                  {activeMaterial.subject}
                </span>
                <div className="flex items-center gap-1.5 text-xs text-[#9aa0a6]">
                  <Clock className="w-3.5 h-3.5 text-[#00d2d3]" />
                  <span>
                    {activeMaterial.readingTimeMinutes || 2} min read ({activeMaterial.wordCount} words)
                  </span>
                </div>
              </div>

              <button
                onClick={onClearActiveMaterial}
                className="flex items-center gap-1.5 text-xs font-semibold px-3 py-1 rounded-xl bg-[#1a1f30] hover:bg-[#262c42] text-[#9aa0a6] hover:text-[#f5f6fa] border border-[#262c42] transition-colors"
                title="Switch or upload new document"
              >
                <ArrowLeftRight className="w-3 h-3 text-[#00d2d3]" />
                <span>Switch / Upload New</span>
              </button>
            </div>

            <h2 className="text-lg sm:text-xl font-bold text-[#f5f6fa] tracking-tight">
              {activeMaterial.title}
            </h2>

            <div className="mt-3 text-xs sm:text-sm text-[#9aa0a6] leading-relaxed">
              {isFullContentExpanded ? (
                <div className="whitespace-pre-wrap max-h-96 overflow-y-auto pr-2 bg-[#121622]/60 p-4 rounded-2xl border border-[#262c42] mt-2">
                  {activeMaterial.content}
                </div>
              ) : (
                <p>
                  {activeMaterial.content.slice(0, 240)}
                  {activeMaterial.content.length > 240 && '...'}
                </p>
              )}
            </div>

            <button
              onClick={() => setIsFullContentExpanded(!isFullContentExpanded)}
              className="flex items-center gap-1 text-xs font-semibold text-[#00d2d3] hover:underline mt-2.5"
            >
              <span>{isFullContentExpanded ? 'Collapse Content' : 'Read Full Passage'}</span>
              {isFullContentExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>

            {/* Quick Navigation Action Grid */}
            <div className="grid grid-cols-3 gap-2.5 mt-6 pt-5 border-t border-[#262c42]">
              <button
                onClick={onNavigateToChat}
                className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#7c4dff] to-[#9d72ff] text-white text-xs font-bold shadow-md shadow-[#7c4dff]/20 hover:opacity-95 transition-all active:scale-95"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Ask AI</span>
              </button>

              <button
                onClick={onNavigateToFlashcards}
                className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-[#1a1f30] hover:bg-[#262c42] text-[#f5f6fa] border border-[#262c42] text-xs font-bold transition-all active:scale-95"
              >
                <Layers className="w-3.5 h-3.5 text-[#9d72ff]" />
                <span>Cards</span>
              </button>

              <button
                onClick={onNavigateToQuiz}
                className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-[#1a1f30] hover:bg-[#262c42] text-[#f5f6fa] border border-[#262c42] text-xs font-bold transition-all active:scale-95"
              >
                <HelpCircle className="w-3.5 h-3.5 text-[#00d2d3]" />
                <span>Quiz</span>
              </button>
            </div>
          </div>

          {/* AI Executive Summary Card */}
          <div className="bg-[#151928] border border-[#262c42] rounded-3xl p-6 shadow-md space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-[#7c4dff]/20 flex items-center justify-center text-[#9d72ff]">
                  <Sparkles className="w-4 h-4" />
                </div>
                <h3 className="text-sm font-bold text-[#f5f6fa]">AI Executive Summary</h3>
              </div>
              <button
                onClick={onGenerateSummary}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#1a1f30] hover:bg-[#262c42] text-[#9d72ff] border border-[#262c42] text-xs font-semibold transition-colors"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Regenerate</span>
              </button>
            </div>

            {activeMaterial.summary ? (
              <p className="text-xs sm:text-sm text-[#f5f6fa] leading-relaxed">
                {activeMaterial.summary}
              </p>
            ) : (
              <p className="text-xs text-[#9aa0a6] italic">
                Summary is being synthesized by AI. Tap 'Regenerate' if you want a fresh overview.
              </p>
            )}

            {activeMaterial.keyTakeaways && activeMaterial.keyTakeaways.length > 0 && (
              <div className="space-y-2 pt-2">
                <h4 className="text-xs font-bold text-[#00d2d3] uppercase tracking-wider">
                  Key Exam Highlights
                </h4>
                <div className="space-y-2">
                  {activeMaterial.keyTakeaways.map((takeaway, idx) => (
                    <div key={idx} className="flex items-start gap-2.5 text-xs text-[#9aa0a6] leading-relaxed">
                      <CheckCircle2 className="w-4 h-4 text-[#00d2d3] shrink-0 mt-0.5" />
                      <span>{takeaway}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* All Saved Materials Library */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#9aa0a6]">
                Your Study Materials ({materials.length})
              </h3>
              <button
                onClick={onOpenPasteDialog}
                className="flex items-center gap-1 text-xs text-[#9d72ff] font-semibold hover:underline"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add More</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {materials.map((doc) => {
                const isSelected = doc.id === activeMaterial.id;
                return (
                  <div
                    key={doc.id}
                    onClick={() => onSelectMaterial(doc)}
                    className={`flex items-center justify-between p-4 rounded-2xl border cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-[#1a1f30] border-[#7c4dff] shadow-md shadow-[#7c4dff]/15'
                        : 'bg-[#151928] border-[#262c42] hover:border-[#7c4dff]/40'
                    }`}
                  >
                    <div className="flex items-center gap-3 overflow-hidden">
                      <div
                        className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                          isSelected ? 'bg-[#7c4dff] text-white' : 'bg-[#1a1f30] text-[#9aa0a6]'
                        }`}
                      >
                        <BookOpen className="w-5 h-5" />
                      </div>
                      <div className="overflow-hidden">
                        <div className="text-xs font-bold text-[#f5f6fa] truncate">
                          {doc.title}
                        </div>
                        <div className="text-[11px] text-[#9aa0a6] flex items-center gap-2 mt-0.5">
                          <span>{doc.subject}</span>
                          <span>•</span>
                          <span>{doc.wordCount} words</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0 ml-2">
                      {isSelected ? (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#7c4dff]/30 text-[#9d72ff]">
                          Active
                        </span>
                      ) : null}
                      {materials.length > 1 && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onDeleteMaterial(doc.id);
                          }}
                          className="p-1.5 rounded-lg text-[#9aa0a6] hover:text-[#ff7675] hover:bg-[#ff7675]/10 transition-colors"
                          title="Delete material"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
