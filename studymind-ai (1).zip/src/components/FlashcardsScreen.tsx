import React, { useState } from 'react';
import { 
  Sparkles, 
  RotateCw, 
  ArrowLeft, 
  ArrowRight, 
  Bookmark, 
  BookmarkCheck, 
  School, 
  Plus, 
  Layers, 
  CheckCircle2, 
  AlertCircle,
  X
} from 'lucide-react';
import { FlashcardItem, StudyMaterial } from '../types';

interface FlashcardsScreenProps {
  activeMaterial: StudyMaterial | null;
  flashcards: FlashcardItem[];
  deckMasteryPercentage: number;
  isLoading: boolean;
  onRateCard: (cardId: string, rating: number) => void;
  onToggleBookmark: (cardId: string) => void;
  onGenerateAiCards: (count: number) => void;
  onAddCustomCard: (question: string, answer: string, topic: string, difficulty: 'Easy' | 'Medium' | 'Hard') => void;
  onNavigateToUpload: () => void;
}

export const FlashcardsScreen: React.FC<FlashcardsScreenProps> = ({
  activeMaterial,
  flashcards,
  deckMasteryPercentage,
  isLoading,
  onRateCard,
  onToggleBookmark,
  onGenerateAiCards,
  onAddCustomCard,
  onNavigateToUpload,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [filterBookmarkedOnly, setFilterBookmarkedOnly] = useState(false);
  const [showAddCardModal, setShowAddCardModal] = useState(false);

  // Filter cards based on bookmark view
  const displayCards = filterBookmarkedOnly
    ? flashcards.filter((c) => c.isBookmarked)
    : flashcards;

  const currentCard = displayCards[currentIndex] || null;

  const handleNext = () => {
    if (displayCards.length === 0) return;
    setIsFlipped(false);
    setCurrentIndex((prev) => (prev + 1) % displayCards.length);
  };

  const handlePrev = () => {
    if (displayCards.length === 0) return;
    setIsFlipped(false);
    setCurrentIndex((prev) => (prev - 1 + displayCards.length) % displayCards.length);
  };

  const handleRate = (rating: number) => {
    if (!currentCard) return;
    onRateCard(currentCard.id, rating);
    handleNext();
  };

  if (!activeMaterial) {
    return (
      <div className="flex flex-col items-center justify-center p-8 text-center max-w-md mx-auto my-12 bg-[#151928] border-2 border-[#9d72ff]/40 rounded-3xl shadow-xl animate-fadeIn">
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-[#7c4dff] to-[#9d72ff] flex items-center justify-center text-white mb-4 shadow-lg shadow-[#7c4dff]/25">
          <Layers className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold text-[#f5f6fa]">Active Recall Flashcards</h2>
        <p className="text-xs text-[#9aa0a6] mt-2 leading-relaxed">
          Upload your notes or choose a starter course to generate interactive spaced-repetition flashcards.
        </p>
        <button
          onClick={onNavigateToUpload}
          className="mt-6 px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#7c4dff] to-[#9d72ff] text-white text-xs font-semibold shadow-md shadow-[#7c4dff]/25 hover:opacity-95 transition-all"
        >
          Go to Workspace / Upload
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-xl mx-auto space-y-5 pb-20 animate-fadeIn">
      {/* Header bar */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-lg sm:text-xl font-bold text-[#f5f6fa]">Active Recall Flashcards</h2>
          <p className="text-xs text-[#00d2d3] font-medium truncate max-w-xs">{activeMaterial.title}</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowAddCardModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#1a1f30] hover:bg-[#262c42] text-[#f5f6fa] border border-[#262c42] text-xs font-semibold transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Card</span>
          </button>

          <button
            onClick={() => onGenerateAiCards(6)}
            disabled={isLoading}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-[#7c4dff] to-[#9d72ff] hover:opacity-95 text-white text-xs font-bold shadow-md shadow-[#7c4dff]/20 transition-all disabled:opacity-50"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI Cards</span>
          </button>
        </div>
      </div>

      {/* Deck Mastery Bar (SM-2) */}
      <div className="bg-[#151928] border border-[#262c42] rounded-2xl p-4 flex items-center gap-3.5 shadow-sm">
        <div className="w-10 h-10 rounded-xl bg-[#7c4dff]/20 flex items-center justify-center text-[#9d72ff] shrink-0">
          <School className="w-5 h-5" />
        </div>
        <div className="flex-1 space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-[#f5f6fa]">Deck Mastery (SM-2 Spaced Repetition)</span>
            <span className="font-bold text-[#00d2d3]">{deckMasteryPercentage}%</span>
          </div>
          <div className="w-full h-2 rounded-full bg-[#1a1f30] overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-[#7c4dff] to-[#00d2d3] transition-all duration-500 rounded-full"
              style={{ width: `${deckMasteryPercentage}%` }}
            />
          </div>
        </div>
      </div>

      {/* Bookmarked Filter Pill */}
      <div className="flex items-center justify-between text-xs px-1">
        <button
          onClick={() => {
            setFilterBookmarkedOnly(!filterBookmarkedOnly);
            setCurrentIndex(0);
            setIsFlipped(false);
          }}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-full border transition-colors ${
            filterBookmarkedOnly
              ? 'bg-[#fdcb6e]/20 border-[#fdcb6e] text-[#fdcb6e]'
              : 'bg-[#151928] border-[#262c42] text-[#9aa0a6] hover:text-[#f5f6fa]'
          }`}
        >
          <Bookmark className="w-3 h-3" />
          <span>{filterBookmarkedOnly ? 'Showing Bookmarked' : 'Show All Cards'}</span>
        </button>

        <span className="text-[#9aa0a6]">
          {displayCards.length} {displayCards.length === 1 ? 'Card' : 'Cards'} Available
        </span>
      </div>

      {/* Interactive 3D Flip Card Canvas */}
      {currentCard ? (
        <div className="space-y-4">
          <div
            onClick={() => setIsFlipped(!isFlipped)}
            className="perspective-1000 w-full h-80 sm:h-96 cursor-pointer select-none"
          >
            <div
              className={`relative w-full h-full duration-500 transform-style-3d transition-transform ${
                isFlipped ? 'rotate-y-180' : ''
              }`}
            >
              {/* FRONT OF CARD (Question) */}
              <div className="absolute inset-0 w-full h-full backface-hidden bg-[#151928] border-2 border-[#7c4dff]/50 rounded-3xl p-6 sm:p-8 flex flex-col justify-between shadow-2xl">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold px-2.5 py-1 rounded-lg bg-[#7c4dff]/20 text-[#9d72ff] uppercase tracking-wider">
                    {currentCard.topic}
                  </span>

                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                        currentCard.difficulty === 'Easy'
                          ? 'bg-[#00b894]/20 text-[#00b894]'
                          : currentCard.difficulty === 'Hard'
                          ? 'bg-[#ff7675]/20 text-[#ff7675]'
                          : 'bg-[#fdcb6e]/20 text-[#fdcb6e]'
                      }`}
                    >
                      {currentCard.difficulty}
                    </span>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleBookmark(currentCard.id);
                      }}
                      className="p-1 rounded-lg text-[#9aa0a6] hover:text-[#fdcb6e] transition-colors"
                    >
                      {currentCard.isBookmarked ? (
                        <BookmarkCheck className="w-5 h-5 text-[#fdcb6e]" />
                      ) : (
                        <Bookmark className="w-5 h-5" />
                      )}
                    </button>
                  </div>
                </div>

                <div className="my-auto text-center px-4">
                  <h3 className="text-base sm:text-lg font-bold text-[#f5f6fa] leading-relaxed">
                    {currentCard.question}
                  </h3>
                </div>

                <div className="flex items-center justify-center gap-1.5 text-xs text-[#00d2d3] font-medium pt-2">
                  <RotateCw className="w-3.5 h-3.5" />
                  <span>Click anywhere to flip for answer</span>
                </div>
              </div>

              {/* BACK OF CARD (Answer) */}
              <div className="absolute inset-0 w-full h-full backface-hidden rotate-y-180 bg-[#1a1f30] border-2 border-[#00d2d3]/50 rounded-3xl p-6 sm:p-8 flex flex-col justify-between shadow-2xl">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-[11px] font-bold text-[#00d2d3] uppercase tracking-wider">
                    Correct Answer
                  </span>
                  <span className="text-[#9aa0a6]">
                    Interval: {currentCard.repetitionIntervalDays || 1}d
                  </span>
                </div>

                <div className="my-auto text-center px-4 overflow-y-auto max-h-44">
                  <p className="text-sm sm:text-base text-[#f5f6fa] leading-relaxed font-normal">
                    {currentCard.answer}
                  </p>
                </div>

                {/* Rating Buttons */}
                <div className="space-y-2 pt-2 border-t border-[#262c42]">
                  <p className="text-[11px] text-center text-[#9aa0a6]">
                    Rate your recall confidence (SM-2):
                  </p>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleRate(1);
                      }}
                      className="py-2 px-1 rounded-xl bg-[#ff7675]/15 hover:bg-[#ff7675]/25 border border-[#ff7675] text-center transition-all active:scale-95"
                    >
                      <div className="text-xs font-bold text-[#ff7675]">Hard</div>
                      <div className="text-[10px] text-[#9aa0a6]">1 day</div>
                    </button>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleRate(3);
                      }}
                      className="py-2 px-1 rounded-xl bg-[#7c4dff]/20 hover:bg-[#7c4dff]/30 border border-[#7c4dff] text-center transition-all active:scale-95"
                    >
                      <div className="text-xs font-bold text-[#9d72ff]">Good</div>
                      <div className="text-[10px] text-[#9aa0a6]">3 days</div>
                    </button>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleRate(5);
                      }}
                      className="py-2 px-1 rounded-xl bg-[#00b894]/15 hover:bg-[#00b894]/25 border border-[#00b894] text-center transition-all active:scale-95"
                    >
                      <div className="text-xs font-bold text-[#00b894]">Easy</div>
                      <div className="text-[10px] text-[#9aa0a6]">6 days</div>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Stepper controls */}
          <div className="flex items-center justify-between pt-2">
            <button
              onClick={handlePrev}
              className="w-11 h-11 rounded-2xl bg-[#151928] hover:bg-[#1a1f30] border border-[#262c42] flex items-center justify-center text-[#f5f6fa] transition-colors active:scale-95"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>

            <span className="text-xs font-bold text-[#f5f6fa]">
              Card {currentIndex + 1} of {displayCards.length}
            </span>

            <button
              onClick={handleNext}
              className="w-11 h-11 rounded-2xl bg-[#151928] hover:bg-[#1a1f30] border border-[#262c42] flex items-center justify-center text-[#f5f6fa] transition-colors active:scale-95"
            >
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      ) : (
        /* Empty Deck State */
        <div className="bg-[#151928] border border-[#262c42] rounded-3xl p-8 text-center space-y-4">
          <Layers className="w-10 h-10 text-[#7c4dff] mx-auto opacity-70" />
          <h3 className="text-sm font-bold text-[#f5f6fa]">No Cards in this View</h3>
          <p className="text-xs text-[#9aa0a6] max-w-xs mx-auto">
            {filterBookmarkedOnly
              ? 'You have not bookmarked any cards yet. Toggle "Show All Cards" above.'
              : 'Tap below to automatically generate active recall cards with Gemini AI.'}
          </p>
          <button
            onClick={() => onGenerateAiCards(6)}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#7c4dff] to-[#9d72ff] text-white text-xs font-semibold shadow-md shadow-[#7c4dff]/25"
          >
            Generate 6 Flashcards
          </button>
        </div>
      )}

      {/* Add Custom Card Modal */}
      {showAddCardModal && (
        <AddCustomCardDialog
          onClose={() => setShowAddCardModal(false)}
          onSubmit={(q, a, t, d) => {
            onAddCustomCard(q, a, t, d);
            setShowAddCardModal(false);
          }}
        />
      )}
    </div>
  );
};

// Subcomponent: Add Custom Card Dialog
interface AddCustomCardDialogProps {
  onClose: () => void;
  onSubmit: (question: string, answer: string, topic: string, difficulty: 'Easy' | 'Medium' | 'Hard') => void;
}

const AddCustomCardDialog: React.FC<AddCustomCardDialogProps> = ({ onClose, onSubmit }) => {
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [topic, setTopic] = useState('');
  const [difficulty, setDifficulty] = useState<'Easy' | 'Medium' | 'Hard'>('Medium');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim() || !answer.trim()) return;
    onSubmit(question.trim(), answer.trim(), topic.trim() || 'Core Concept', difficulty);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fadeIn">
      <div className="bg-[#121622] border border-[#262c42] rounded-2xl w-full max-w-md p-6 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-[#9aa0a6] hover:text-white p-1 rounded-lg hover:bg-[#1a1f30] transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <h3 className="text-base font-bold text-[#f5f6fa] mb-4">Add Custom Flashcard</h3>

        <form onSubmit={handleSubmit} className="space-y-3.5">
          <div>
            <label className="block text-xs font-semibold text-[#9aa0a6] mb-1">Question / Prompt</label>
            <textarea
              required
              rows={3}
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="e.g. What is the time complexity of Dijkstra's algorithm?"
              className="w-full bg-[#1a1f30] border border-[#262c42] focus:border-[#9d72ff] rounded-xl p-3 text-xs text-[#f5f6fa] outline-none resize-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#9aa0a6] mb-1">Answer</label>
            <textarea
              required
              rows={3}
              value={answer}
              onChange={(e) => setAnswer(e.target.value)}
              placeholder="e.g. O((V + E) log V) using a Binary Min-Heap PriorityQueue."
              className="w-full bg-[#1a1f30] border border-[#262c42] focus:border-[#9d72ff] rounded-xl p-3 text-xs text-[#f5f6fa] outline-none resize-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-[#9aa0a6] mb-1">Topic</label>
              <input
                type="text"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder="e.g. Graph Theory"
                className="w-full bg-[#1a1f30] border border-[#262c42] focus:border-[#9d72ff] rounded-xl px-3 py-2 text-xs text-[#f5f6fa] outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#9aa0a6] mb-1">Difficulty</label>
              <select
                value={difficulty}
                onChange={(e) => setDifficulty(e.target.value as any)}
                className="w-full bg-[#1a1f30] border border-[#262c42] focus:border-[#9d72ff] rounded-xl px-3 py-2 text-xs text-[#f5f6fa] outline-none"
              >
                <option value="Easy">Easy</option>
                <option value="Medium">Medium</option>
                <option value="Hard">Hard</option>
              </select>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs text-[#9aa0a6] hover:text-white rounded-xl hover:bg-[#1a1f30]"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-[#7c4dff] text-white text-xs font-semibold shadow-md shadow-[#7c4dff]/25"
            >
              Add Card
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
