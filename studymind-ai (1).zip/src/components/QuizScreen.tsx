import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  HelpCircle, 
  Check, 
  X, 
  Trophy, 
  RefreshCw, 
  ArrowRight, 
  Award,
  AlertCircle,
  CheckCircle2
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { QuizQuestion, QuizResult, StudyMaterial } from '../types';
import { evaluateQuiz } from '../domain/quizScorer';

interface QuizScreenProps {
  activeMaterial: StudyMaterial | null;
  quizQuestions: QuizQuestion[];
  isLoading: boolean;
  onSaveQuizResult: (result: QuizResult) => void;
  onGenerateAiQuiz: (count: number) => void;
  onNavigateToUpload: () => void;
}

export const QuizScreen: React.FC<QuizScreenProps> = ({
  activeMaterial,
  quizQuestions,
  isLoading,
  onSaveQuizResult,
  onGenerateAiQuiz,
  onNavigateToUpload,
}) => {
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFinished, setIsFinished] = useState(false);
  const [quizResult, setQuizResult] = useState<QuizResult | null>(null);

  // Sync questions with props
  useEffect(() => {
    setQuestions(quizQuestions.map(q => ({ ...q, selectedOptionIndex: undefined })));
    setCurrentIndex(0);
    setIsFinished(false);
    setQuizResult(null);
  }, [quizQuestions]);

  const currentQ = questions[currentIndex] || null;
  const progress = questions.length > 0 ? (currentIndex + 1) / questions.length : 0;

  const handleSelectOption = (optionIndex: number) => {
    if (!currentQ || currentQ.selectedOptionIndex !== undefined) return;

    const updated = [...questions];
    updated[currentIndex] = { ...currentQ, selectedOptionIndex: optionIndex };
    setQuestions(updated);
  };

  const handleNext = () => {
    if (currentIndex + 1 < questions.length) {
      setCurrentIndex((prev) => prev + 1);
    } else {
      // Evaluate Quiz
      const result = evaluateQuiz(questions, activeMaterial?.id, activeMaterial?.title);
      setQuizResult(result);
      setIsFinished(true);
      onSaveQuizResult(result);

      // Trigger celebratory confetti if passed well
      if (result.scorePercentage >= 70) {
        try {
          confetti({
            particleCount: 80,
            spread: 70,
            origin: { y: 0.6 },
            colors: ['#7c4dff', '#9d72ff', '#00d2d3', '#00b894'],
          });
        } catch (e) {
          // ignore confetti if unsupported
        }
      }
    }
  };

  const handleRestart = () => {
    setQuestions(questions.map((q) => ({ ...q, selectedOptionIndex: undefined })));
    setCurrentIndex(0);
    setIsFinished(false);
    setQuizResult(null);
  };

  if (!activeMaterial) {
    return (
      <div className="flex flex-col items-center justify-center p-8 text-center max-w-md mx-auto my-12 bg-[#151928] border-2 border-[#9d72ff]/40 rounded-3xl shadow-xl animate-fadeIn">
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-[#7c4dff] to-[#9d72ff] flex items-center justify-center text-white mb-4 shadow-lg shadow-[#7c4dff]/25">
          <HelpCircle className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold text-[#f5f6fa]">Practice Quizzes & Exams</h2>
        <p className="text-xs text-[#9aa0a6] mt-2 leading-relaxed">
          Upload your notes or pick a curriculum to generate rigorous multiple-choice assessments with instant feedback.
        </p>
        <button
          onClick={onNavigateToUpload}
          className="mt-6 px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#7c4dff] to-[#9d72ff] text-white text-xs font-semibold shadow-md shadow-[#7c4dff]/25 hover:opacity-95 transition-all"
        >
          Go to Workspace / Upload
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-xl mx-auto space-y-5 pb-20 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-lg sm:text-xl font-bold text-[#f5f6fa]">Practice Quiz</h2>
          <p className="text-xs text-[#00d2d3] font-medium truncate max-w-xs">{activeMaterial.title}</p>
        </div>

        <button
          onClick={() => onGenerateAiQuiz(5)}
          disabled={isLoading}
          className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-[#7c4dff] to-[#9d72ff] hover:opacity-95 text-white text-xs font-bold shadow-md shadow-[#7c4dff]/20 transition-all disabled:opacity-50"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>AI Exam</span>
        </button>
      </div>

      {/* QUIZ SCORECARD SCREEN: Displayed after quiz finishes */}
      {isFinished && quizResult ? (
        <div className="bg-[#151928] border-2 border-[#9d72ff]/50 rounded-3xl p-6 sm:p-8 text-center space-y-6 shadow-2xl animate-scaleUp">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-[#7c4dff] to-[#9d72ff] mx-auto flex items-center justify-center text-white shadow-xl shadow-[#7c4dff]/30">
            <Trophy className="w-8 h-8" />
          </div>

          <div>
            <h3 className="text-xl font-bold text-[#f5f6fa]">Quiz Assessment Completed</h3>
            <p className="text-xs text-[#9aa0a6] mt-1">Review your results and pedagogical feedback below</p>
          </div>

          {/* Metric Badges */}
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-[#1a1f30] border border-[#262c42] rounded-2xl p-3.5">
              <div className="text-[10px] font-bold text-[#9aa0a6] uppercase tracking-wider">SCORE</div>
              <div className="text-2xl font-black text-[#00d2d3] mt-1">{quizResult.scorePercentage}%</div>
            </div>

            <div className="bg-[#1a1f30] border border-[#262c42] rounded-2xl p-3.5">
              <div className="text-[10px] font-bold text-[#9aa0a6] uppercase tracking-wider">GRADE</div>
              <div className="text-2xl font-black text-[#9d72ff] mt-1">{quizResult.gradeLetter}</div>
            </div>

            <div className="bg-[#1a1f30] border border-[#262c42] rounded-2xl p-3.5">
              <div className="text-[10px] font-bold text-[#9aa0a6] uppercase tracking-wider">CORRECT</div>
              <div className="text-2xl font-black text-[#00b894] mt-1">
                {quizResult.correctAnswers} / {quizResult.totalQuestions}
              </div>
            </div>
          </div>

          {/* Feedback Card */}
          <div className="bg-[#1a1f30] border border-[#262c42] rounded-2xl p-4 text-left space-y-1.5">
            <div className="text-xs font-bold text-[#9d72ff] uppercase tracking-wider">
              Pedagogical Feedback
            </div>
            <p className="text-xs text-[#f5f6fa] leading-relaxed">{quizResult.feedbackMessage}</p>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-3 pt-2">
            <button
              onClick={handleRestart}
              className="flex-1 flex items-center justify-center gap-2 py-3 rounded-2xl bg-[#1a1f30] hover:bg-[#262c42] text-[#f5f6fa] border border-[#262c42] text-xs font-bold transition-all active:scale-95"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Retake Quiz</span>
            </button>

            <button
              onClick={() => onGenerateAiQuiz(5)}
              className="flex-1 flex items-center justify-center gap-2 py-3 rounded-2xl bg-gradient-to-r from-[#7c4dff] to-[#9d72ff] text-white text-xs font-bold shadow-md shadow-[#7c4dff]/25 hover:opacity-95 transition-all active:scale-95"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>New AI Exam</span>
            </button>
          </div>
        </div>
      ) : currentQ ? (
        /* QUESTION STEPPER VIEW */
        <div className="space-y-4">
          {/* Progress Header */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs font-semibold">
              <span className="text-[#9d72ff]">
                Question {currentIndex + 1} of {questions.length}
              </span>
              <span className="text-[#9aa0a6]">{Math.round(progress * 100)}% Completed</span>
            </div>
            <div className="w-full h-1.5 rounded-full bg-[#1a1f30] overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-[#7c4dff] to-[#00d2d3] transition-all duration-300 rounded-full"
                style={{ width: `${progress * 100}%` }}
              />
            </div>
          </div>

          {/* Question Card */}
          <div className="bg-[#151928] border border-[#262c42] rounded-3xl p-6 sm:p-7 shadow-xl space-y-5">
            <h3 className="text-base sm:text-lg font-bold text-[#f5f6fa] leading-relaxed">
              {currentQ.questionText}
            </h3>

            {/* Options */}
            <div className="space-y-2.5">
              {currentQ.options.map((option, optIdx) => {
                const isSelected = currentQ.selectedOptionIndex === optIdx;
                const isAnswered = currentQ.selectedOptionIndex !== undefined;
                const isCorrectOption = optIdx === currentQ.correctAnswerIndex;

                let borderStyle = 'border-[#262c42] bg-[#1a1f30] hover:border-[#7c4dff]/60';
                let badgeStyle = 'bg-[#121622] text-[#9aa0a6]';

                if (isAnswered) {
                  if (isCorrectOption) {
                    borderStyle = 'border-[#00b894] bg-[#00b894]/15';
                    badgeStyle = 'bg-[#00b894] text-black';
                  } else if (isSelected && !isCorrectOption) {
                    borderStyle = 'border-[#ff7675] bg-[#ff7675]/15';
                    badgeStyle = 'bg-[#ff7675] text-white';
                  } else {
                    borderStyle = 'border-[#262c42] bg-[#1a1f30]/50 opacity-60';
                  }
                } else if (isSelected) {
                  borderStyle = 'border-[#7c4dff] bg-[#7c4dff]/20';
                  badgeStyle = 'bg-[#7c4dff] text-white';
                }

                return (
                  <button
                    key={optIdx}
                    onClick={() => handleSelectOption(optIdx)}
                    disabled={isAnswered}
                    className={`w-full flex items-center gap-3 p-3.5 rounded-2xl border text-left transition-all ${borderStyle}`}
                  >
                    <div
                      className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs shrink-0 ${badgeStyle}`}
                    >
                      {isAnswered && isCorrectOption ? (
                        <Check className="w-4 h-4 stroke-[3]" />
                      ) : isAnswered && isSelected && !isCorrectOption ? (
                        <X className="w-4 h-4 stroke-[3]" />
                      ) : (
                        String.fromCharCode(65 + optIdx)
                      )}
                    </div>
                    <span className="text-xs sm:text-sm text-[#f5f6fa] flex-1 leading-snug">
                      {option}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Explanation card displayed upon answer */}
            {currentQ.selectedOptionIndex !== undefined && (
              <div
                className={`p-4 rounded-2xl border text-xs leading-relaxed space-y-1.5 animate-fadeIn ${
                  currentQ.selectedOptionIndex === currentQ.correctAnswerIndex
                    ? 'bg-[#00b894]/10 border-[#00b894]/40 text-[#f5f6fa]'
                    : 'bg-[#ff7675]/10 border-[#ff7675]/40 text-[#f5f6fa]'
                }`}
              >
                <div className="flex items-center gap-1.5 font-bold">
                  {currentQ.selectedOptionIndex === currentQ.correctAnswerIndex ? (
                    <>
                      <CheckCircle2 className="w-4 h-4 text-[#00b894]" />
                      <span className="text-[#00b894]">Correct! Pedagogical Insight:</span>
                    </>
                  ) : (
                    <>
                      <AlertCircle className="w-4 h-4 text-[#ff7675]" />
                      <span className="text-[#ff7675]">Incorrect. Concept Clarification:</span>
                    </>
                  )}
                </div>
                <p>{currentQ.explanation}</p>
              </div>
            )}

            {/* Next Question / View Scorecard Button */}
            <button
              onClick={handleNext}
              disabled={currentQ.selectedOptionIndex === undefined}
              className="w-full flex items-center justify-center gap-2 py-3 rounded-2xl bg-gradient-to-r from-[#7c4dff] to-[#9d72ff] hover:opacity-95 text-white text-xs sm:text-sm font-bold shadow-md shadow-[#7c4dff]/25 transition-all disabled:opacity-30 disabled:cursor-not-allowed active:scale-95"
            >
              <span>{currentIndex + 1 < questions.length ? 'Next Question' : 'View Scorecard'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      ) : (
        /* Empty Quiz State */
        <div className="bg-[#151928] border border-[#262c42] rounded-3xl p-8 text-center space-y-4">
          <HelpCircle className="w-10 h-10 text-[#00d2d3] mx-auto opacity-70" />
          <h3 className="text-sm font-bold text-[#f5f6fa]">No Active Practice Quiz</h3>
          <p className="text-xs text-[#9aa0a6] max-w-xs mx-auto">
            Generate an interactive exam with Gemini AI to test your command of this material.
          </p>
          <button
            onClick={() => onGenerateAiQuiz(5)}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#7c4dff] to-[#9d72ff] text-white text-xs font-semibold shadow-md shadow-[#7c4dff]/25"
          >
            Generate 5-Question Quiz
          </button>
        </div>
      )}
    </div>
  );
};
