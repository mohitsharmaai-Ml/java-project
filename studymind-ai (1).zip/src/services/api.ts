import { StudyMaterial, FlashcardItem, QuizQuestion, QuizResult, StudyChatMessage, DatabaseState } from '../types';

const STORAGE_KEY = 'studymind_local_cache_v1';

export class ApiService {
  /**
   * Health check to detect server and Gemini configuration status
   */
  static async getHealth(): Promise<{ status: string; geminiConfigured: boolean; materialsCount: number }> {
    try {
      const res = await fetch('/api/health');
      if (!res.ok) throw new Error('Health check failed');
      return await res.json();
    } catch {
      return { status: 'offline', geminiConfigured: false, materialsCount: 0 };
    }
  }

  static async extractDocument(base64Data: string, fileName: string): Promise<{ text: string; wordCount: number; readingTimeMinutes: number }> {
    const res = await fetch('/api/extract-document', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ base64Data, fileName }),
    });
    if (!res.ok) throw new Error('Failed to extract document text');
    return await res.json();
  }

  /**
   * Fetch all study materials
   */
  static async getMaterials(): Promise<StudyMaterial[]> {
    try {
      const res = await fetch('/api/materials');
      if (!res.ok) throw new Error('Failed to fetch materials');
      const data = await res.json();
      return data;
    } catch (e) {
      console.warn('API getMaterials failed, falling back to cache:', e);
      const cache = this.getLocalCache();
      return cache.materials;
    }
  }

  /**
   * Save a newly uploaded or pasted study document
   */
  static async createMaterial(title: string, content: string, subject: string): Promise<StudyMaterial> {
    const res = await fetch('/api/materials', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, content, subject }),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to create document');
    }
    return await res.json();
  }

  /**
   * Update study material
   */
  static async updateMaterial(id: string, updates: Partial<StudyMaterial>): Promise<StudyMaterial> {
    const res = await fetch(`/api/materials/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates),
    });
    if (!res.ok) throw new Error('Failed to update document');
    return await res.json();
  }

  /**
   * Delete study material
   */
  static async deleteMaterial(id: string): Promise<void> {
    const res = await fetch(`/api/materials/${id}`, { method: 'DELETE' });
    if (!res.ok) throw new Error('Failed to delete document');
  }

  /**
   * Generate Executive Summary and Key Takeaways
   */
  static async generateSummary(
    documentId: string,
    title: string,
    content: string
  ): Promise<{ summary: string; keyTakeaways: string[]; source: string }> {
    const res = await fetch('/api/generate-summary', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ documentId, title, content }),
    });
    if (!res.ok) throw new Error('Failed to generate summary');
    return await res.json();
  }

  /**
   * Ask doubt grounded in document
   */
  static async askDoubt(
    documentId: string,
    title: string,
    content: string,
    question: string,
    history: { text: string; isUser: boolean }[] = []
  ): Promise<{ answer: string; source: string }> {
    const res = await fetch('/api/ask-doubt', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ documentId, title, content, question, history }),
    });
    if (!res.ok) throw new Error('Failed to get answer');
    return await res.json();
  }

  /**
   * Generate Flashcards
   */
  static async generateFlashcards(
    documentId: string,
    title: string,
    content: string,
    count: number = 6
  ): Promise<{ flashcards: FlashcardItem[]; source: string }> {
    const res = await fetch('/api/generate-flashcards', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ documentId, title, content, count }),
    });
    if (!res.ok) throw new Error('Failed to generate flashcards');
    return await res.json();
  }

  /**
   * Fetch flashcards for document
   */
  static async getFlashcards(docId?: string): Promise<FlashcardItem[]> {
    const url = docId ? `/api/flashcards?docId=${encodeURIComponent(docId)}` : '/api/flashcards';
    const res = await fetch(url);
    if (!res.ok) throw new Error('Failed to fetch flashcards');
    return await res.json();
  }

  /**
   * Review flashcard with SM-2 spaced repetition rating
   */
  static async reviewCard(cardId: string, rating: number): Promise<{ card: FlashcardItem; mastery: number }> {
    const res = await fetch('/api/flashcards/review', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ cardId, rating }),
    });
    if (!res.ok) throw new Error('Failed to review card');
    return await res.json();
  }

  /**
   * Toggle flashcard bookmark
   */
  static async bookmarkCard(cardId: string): Promise<FlashcardItem> {
    const res = await fetch('/api/flashcards/bookmark', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ cardId }),
    });
    if (!res.ok) throw new Error('Failed to bookmark card');
    const data = await res.json();
    return data.card;
  }

  /**
   * Create custom flashcard
   */
  static async createFlashcard(
    documentId: string,
    question: string,
    answer: string,
    topic: string,
    difficulty: 'Easy' | 'Medium' | 'Hard'
  ): Promise<FlashcardItem> {
    const res = await fetch('/api/flashcards', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ documentId, question, answer, topic, difficulty }),
    });
    if (!res.ok) throw new Error('Failed to add custom flashcard');
    return await res.json();
  }

  /**
   * Generate Quiz Questions
   */
  static async generateQuiz(
    documentId: string,
    title: string,
    content: string,
    count: number = 5
  ): Promise<{ questions: QuizQuestion[]; source: string }> {
    const res = await fetch('/api/generate-quiz', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ documentId, title, content, count }),
    });
    if (!res.ok) throw new Error('Failed to generate quiz');
    return await res.json();
  }

  /**
   * Fetch quiz questions for document
   */
  static async getQuizQuestions(docId?: string): Promise<QuizQuestion[]> {
    const url = docId ? `/api/quiz-questions?docId=${encodeURIComponent(docId)}` : '/api/quiz-questions';
    const res = await fetch(url);
    if (!res.ok) throw new Error('Failed to fetch quiz questions');
    return await res.json();
  }

  /**
   * Save quiz attempt scorecard
   */
  static async saveQuizResult(result: QuizResult): Promise<QuizResult> {
    const res = await fetch('/api/quiz-results', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(result),
    });
    if (!res.ok) throw new Error('Failed to save quiz result');
    return await res.json();
  }

  /**
   * Get all quiz results history
   */
  static async getQuizResults(): Promise<QuizResult[]> {
    const res = await fetch('/api/quiz-results');
    if (!res.ok) throw new Error('Failed to fetch quiz results');
    return await res.json();
  }

  /**
   * Explain a concept simply or deeply
   */
  static async explainConcept(
    concept: string,
    content: string,
    isSimplified: boolean
  ): Promise<{ explanation: string; source: string }> {
    const res = await fetch('/api/explain-concept', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ concept, content, isSimplified }),
    });
    if (!res.ok) throw new Error('Failed to explain concept');
    return await res.json();
  }

  /**
   * Get full database state
   */
  static async getFullDatabase(): Promise<any> {
    const res = await fetch('/api/database');
    if (!res.ok) throw new Error('Failed to export database');
    return await res.json();
  }

  /**
   * Reset database to defaults
   */
  static async resetDatabase(): Promise<any> {
    const res = await fetch('/api/database/reset', { method: 'POST' });
    if (!res.ok) throw new Error('Failed to reset database');
    return await res.json();
  }

  /**
   * Import database JSON
   */
  static async importDatabase(data: any): Promise<any> {
    const res = await fetch('/api/database/import', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Failed to import database');
    return await res.json();
  }

  // Local storage caching helpers
  static getLocalCache(): DatabaseState {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) return JSON.parse(raw);
    } catch (e) {
      console.warn('Failed to parse localStorage cache:', e);
    }
    return {
      materials: [],
      flashcards: [],
      quizResults: [],
      chatMessages: {},
      lastUpdated: 0,
    };
  }

  static setLocalCache(state: DatabaseState): void {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (e) {
      console.warn('Failed to save to localStorage:', e);
    }
  }
}
