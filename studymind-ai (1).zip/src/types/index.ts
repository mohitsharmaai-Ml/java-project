export interface StudyMaterial {
  id: string;
  title: string;
  content: string;
  subject: string;
  wordCount: number;
  createdAt: number;
  summary: string;
  keyTakeaways: string[];
  isPreloaded: boolean;
  readingTimeMinutes?: number;
}

export interface FlashcardItem {
  id: string;
  documentId: string;
  question: string;
  answer: string;
  topic: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  repetitionIntervalDays: number;
  easeFactor: number;
  reviewCount: number;
  lastReviewedTimestamp: number;
  isBookmarked: boolean;
}

export interface QuizQuestion {
  id: string;
  documentId: string;
  questionText: string;
  options: string[];
  correctAnswerIndex: number;
  explanation: string;
  selectedOptionIndex?: number;
}

export interface QuizResult {
  id?: string;
  documentId?: string;
  documentTitle?: string;
  totalQuestions: number;
  correctAnswers: number;
  incorrectAnswers: number;
  scorePercentage: number;
  gradeLetter: string;
  feedbackMessage: string;
  timestamp?: number;
}

export interface StudyChatMessage {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: number;
  documentTitle?: string;
}

export interface DatabaseState {
  materials: StudyMaterial[];
  flashcards: FlashcardItem[];
  quizResults: QuizResult[];
  chatMessages: Record<string, StudyChatMessage[]>; // keyed by documentId
  lastUpdated: number;
}

export type AppTab = 'workspace' | 'ask_ai' | 'flashcards' | 'quiz';
