const MAX_CONTEXT_CHARS = 16000;

/**
 * Sanitizes and normalizes text from uploads or pasted notes
 */
export function cleanText(rawText: string): string {
  if (!rawText) return '';
  return rawText
    .replace(/\r\n/g, '\n')
    .replace(/\r/g, '\n')
    .replace(/[\t ]+/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

/**
 * Calculates word count
 */
export function countWords(text: string): number {
  if (!text || !text.trim()) return 0;
  return text.trim().split(/\s+/).length;
}

/**
 * Estimates reading time in minutes (assuming 200 words/min)
 */
export function estimateReadingTime(wordCount: number): number {
  return Math.max(1, Math.ceil(wordCount / 200));
}

/**
 * Prepares context window preserving sentence boundaries
 */
export function prepareContextForPrompt(fullText: string): string {
  if (!fullText) return '';
  const cleaned = cleanText(fullText);
  if (cleaned.length <= MAX_CONTEXT_CHARS) {
    return cleaned;
  }
  const lastPeriod = cleaned.lastIndexOf('.', MAX_CONTEXT_CHARS);
  if (lastPeriod > MAX_CONTEXT_CHARS / 2) {
    return cleaned.substring(0, lastPeriod + 1);
  }
  return cleaned.substring(0, MAX_CONTEXT_CHARS);
}

/**
 * Extracts potential topic headings from text
 */
export function extractPotentialTopics(text: string): string[] {
  const topics: string[] = [];
  if (!text) return topics;

  const lines = text.split('\n');
  const headingRegex = /^(?:[0-9]+\.|\*+|#+|[A-Z][a-zA-Z\s]{2,40}:)\s*(.+)/;

  for (const line of lines) {
    const match = line.trim().match(headingRegex);
    if (match && match[1]) {
      const topic = match[1].trim();
      if (topic.length > 3 && topic.length < 60 && !topics.includes(topic)) {
        topics.push(topic);
        if (topics.length >= 6) break;
      }
    }
  }

  if (topics.length === 0) {
    topics.push('Key Concepts', 'Definitions & Principles', 'Applications & Exam Insights');
  }

  return topics;
}

/**
 * Extract readable text from raw PDF ArrayBuffer
 */
export function extractTextFromPdfBuffer(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let raw = '';
  // Convert binary to string
  for (let i = 0; i < bytes.length; i++) {
    raw += String.fromCharCode(bytes[i]);
  }

  let textBuilder = '';

  // 1. Text blocks: BT ... ET
  const btEtRegex = /BT\s*([\s\S]*?)\s*ET/g;
  let match: RegExpExecArray | null;

  while ((match = btEtRegex.exec(raw)) !== null) {
    const block = match[1];
    const textOpRegex = /\((.*?)\)\s*(?:Tj|'|")|\[(.*?)\]\s*TJ/g;
    let opMatch: RegExpExecArray | null;

    while ((opMatch = textOpRegex.exec(block)) !== null) {
      if (opMatch[1] !== undefined) {
        textBuilder += cleanPdfString(opMatch[1]) + ' ';
      } else if (opMatch[2] !== undefined) {
        const innerRegex = /\((.*?)\)/g;
        let innerMatch: RegExpExecArray | null;
        while ((innerMatch = innerRegex.exec(opMatch[2])) !== null) {
          textBuilder += cleanPdfString(innerMatch[1]);
        }
        textBuilder += ' ';
      }
    }
    textBuilder += '\n';
  }

  let result = textBuilder.trim();

  // Fallback: If not enough text found from BT/ET, search for printable text sequences
  if (result.length < 40) {
    const fallbackWords = raw.match(/[A-Za-z0-9,.:;?'"!\\-\s]{5,}/g) || [];
    const validWords = fallbackWords
      .map(w => w.trim())
      .filter(w => w.length > 15 && !w.includes('obj') && !w.includes('endobj') && !w.includes('xref'));
    result = validWords.join(' ');
  }

  return cleanText(result);
}

function cleanPdfString(raw: string): string {
  return raw
    .replace(/\\\(/g, '(')
    .replace(/\\\)/g, ')')
    .replace(/\\\\/g, '\\')
    .replace(/\\r/g, '\n')
    .replace(/\\n/g, '\n')
    .replace(/\\t/g, ' ');
}
