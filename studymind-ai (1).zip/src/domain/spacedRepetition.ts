import { FlashcardItem } from '../types';

export const RATING_HARD = 1;
export const RATING_GOOD = 3;
export const RATING_EASY = 5;

/**
 * SuperMemo 2 (SM-2) Spaced Repetition calculation
 * Updates review intervals and ease factors based on recall rating.
 */
export function processReview(card: FlashcardItem, rating: number): FlashcardItem {
  const updatedCard = { ...card };
  updatedCard.reviewCount += 1;
  updatedCard.lastReviewedTimestamp = Date.now();

  const ef = updatedCard.easeFactor || 2.5;
  const interval = updatedCard.repetitionIntervalDays || 1;
  const reviews = updatedCard.reviewCount;

  // EF' = EF + (0.1 - (5 - q) * (0.08 + (5 - q) * 0.02))
  const updatedEf = ef + (0.1 - (5 - rating) * (0.08 + (5 - rating) * 0.02));
  updatedCard.easeFactor = Math.max(1.3, Number(updatedEf.toFixed(2)));

  if (rating === RATING_HARD) {
    updatedCard.repetitionIntervalDays = 1;
    updatedCard.difficulty = 'Hard';
  } else if (rating === RATING_GOOD) {
    if (reviews === 1) {
      updatedCard.repetitionIntervalDays = 1;
    } else if (reviews === 2) {
      updatedCard.repetitionIntervalDays = 3;
    } else {
      updatedCard.repetitionIntervalDays = Math.max(1, Math.round(interval * updatedCard.easeFactor));
    }
    updatedCard.difficulty = 'Medium';
  } else {
    // RATING_EASY
    if (reviews === 1) {
      updatedCard.repetitionIntervalDays = 3;
    } else if (reviews === 2) {
      updatedCard.repetitionIntervalDays = 6;
    } else {
      updatedCard.repetitionIntervalDays = Math.max(1, Math.round(interval * updatedCard.easeFactor * 1.3));
    }
    updatedCard.difficulty = 'Easy';
  }

  return updatedCard;
}

/**
 * Computes deck mastery percentage (0% to 100%)
 */
export function calculateDeckMastery(deck: FlashcardItem[]): number {
  if (!deck || deck.length === 0) return 0;

  let totalWeight = 0;
  for (const card of deck) {
    if (card.reviewCount === 0) {
      totalWeight += 0;
    } else if (card.difficulty.toLowerCase() === 'easy') {
      totalWeight += 100;
    } else if (card.difficulty.toLowerCase() === 'medium') {
      totalWeight += 60;
    } else {
      totalWeight += 25;
    }
  }

  return Math.min(100, Math.round(totalWeight / deck.length));
}
