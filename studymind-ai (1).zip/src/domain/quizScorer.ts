import { QuizQuestion, QuizResult } from '../types';

export function evaluateQuiz(
  questions: QuizQuestion[],
  documentId?: string,
  documentTitle?: string
): QuizResult {
  if (!questions || questions.length === 0) {
    return {
      documentId,
      documentTitle,
      totalQuestions: 0,
      correctAnswers: 0,
      incorrectAnswers: 0,
      scorePercentage: 0,
      gradeLetter: 'N/A',
      feedbackMessage: 'No questions evaluated.',
      timestamp: Date.now(),
    };
  }

  const total = questions.length;
  let correct = 0;

  for (const q of questions) {
    if (q.selectedOptionIndex !== undefined && q.selectedOptionIndex === q.correctAnswerIndex) {
      correct++;
    }
  }

  const incorrect = total - correct;
  const percentage = Math.round((correct / total) * 100);

  let gradeLetter: string;
  let feedbackMessage: string;

  if (percentage >= 90) {
    gradeLetter = 'A+';
    feedbackMessage = 'Mastery demonstrated! Outstanding command of the study concepts.';
  } else if (percentage >= 80) {
    gradeLetter = 'A';
    feedbackMessage = 'Great performance! You have a solid grasp of key principles.';
  } else if (percentage >= 70) {
    gradeLetter = 'B';
    feedbackMessage = 'Good effort! Review the flashcards on your missed questions to solidify understanding.';
  } else if (percentage >= 50) {
    gradeLetter = 'C';
    feedbackMessage = 'Needs review. Try asking Gemini AI to clarify difficult topics in the Ask AI tab.';
  } else {
    gradeLetter = 'Review Needed';
    feedbackMessage = 'Start with the document summary and review flashcard decks before re-testing.';
  }

  return {
    documentId,
    documentTitle,
    totalQuestions: total,
    correctAnswers: correct,
    incorrectAnswers: incorrect,
    scorePercentage: percentage,
    gradeLetter,
    feedbackMessage,
    timestamp: Date.now(),
  };
}
