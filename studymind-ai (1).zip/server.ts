import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI, Type } from '@google/genai';
import { STARTER_MATERIALS, STARTER_FLASHCARDS, STARTER_QUIZZES } from './src/data/starterPacks';
import { 
  cleanText, 
  prepareContextForPrompt, 
  extractPotentialTopics, 
  countWords, 
  estimateReadingTime,
  extractTextFromPdfBuffer 
} from './src/domain/textExtractor';
import { processReview, calculateDeckMastery } from './src/domain/spacedRepetition';
import { evaluateQuiz } from './src/domain/quizScorer';
import { StudyMaterial, FlashcardItem, QuizQuestion, QuizResult } from './src/types';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;
const DATA_DIR = path.resolve(__dirname, 'data');
const DB_FILE = path.resolve(DATA_DIR, 'database.json');

app.use(express.json({ limit: '50mb' }));

// Ensure database directory and file exist
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

interface DatabaseSchema {
  materials: StudyMaterial[];
  flashcards: FlashcardItem[];
  quizQuestions: QuizQuestion[];
  quizResults: QuizResult[];
  chatHistory: Record<string, { id: string; text: string; isUser: boolean; timestamp: number }[]>;
  lastUpdated: number;
}

function loadDatabase(): DatabaseSchema {
  try {
    if (fs.existsSync(DB_FILE)) {
      const data = fs.readFileSync(DB_FILE, 'utf-8');
      return JSON.parse(data);
    }
  } catch (err) {
    console.error('Error loading database, falling back to starter packs:', err);
  }

  // Initial seed with full starter packs
  const initialDb: DatabaseSchema = {
    materials: [...STARTER_MATERIALS],
    flashcards: [...STARTER_FLASHCARDS],
    quizQuestions: [...STARTER_QUIZZES],
    quizResults: [],
    chatHistory: {},
    lastUpdated: Date.now(),
  };
  saveDatabase(initialDb);
  return initialDb;
}

function saveDatabase(db: DatabaseSchema) {
  try {
    db.lastUpdated = Date.now();
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving database:', err);
  }
}

// Initialize DB in memory & disk
let db = loadDatabase();

// Google GenAI initialization with User-Agent header
const apiKey = process.env.GEMINI_API_KEY || '';
const isGeminiConfigured = Boolean(apiKey && apiKey !== 'MY_GEMINI_API_KEY' && apiKey.trim().length > 5);

let ai: GoogleGenAI | null = null;
if (isGeminiConfigured) {
  ai = new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Timeout safeguard for AI API calls to ensure zero hang (3 seconds)
function withTimeout<T>(promise: Promise<T>, ms: number = 3000): Promise<T> {
  return Promise.race([
    promise,
    new Promise<T>((_, reject) => setTimeout(() => reject(new Error('AI generation timed out')), ms)),
  ]);
}

// -----------------------------------------------------------------------------
// REST API ROUTES
// -----------------------------------------------------------------------------

// Document Text Extraction Endpoint
app.post('/api/extract-document', (req: Request, res: Response) => {
  try {
    const { base64Data, fileName = 'document.txt' } = req.body;
    if (!base64Data) {
      return res.status(400).json({ error: 'No document data provided' });
    }

    const buffer = Buffer.from(base64Data, 'base64');
    let text = '';

    if (fileName.toLowerCase().endsWith('.pdf')) {
      text = extractTextFromPdfBuffer(buffer.buffer.slice(buffer.byteOffset, buffer.byteOffset + buffer.byteLength));
    } else {
      text = buffer.toString('utf-8');
    }

    const cleaned = cleanText(text);
    const words = countWords(cleaned);
    const readingTime = estimateReadingTime(words);

    res.json({
      fileName,
      text: cleaned,
      wordCount: words,
      readingTimeMinutes: readingTime,
      success: cleaned.length > 10,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to extract document' });
  }
});

// 1. Health & Status
app.get('/api/health', (req: Request, res: Response) => {
  res.json({
    status: 'ok',
    geminiConfigured: isGeminiConfigured,
    materialsCount: db.materials.length,
    flashcardsCount: db.flashcards.length,
    quizResultsCount: db.quizResults.length,
    lastUpdated: db.lastUpdated,
  });
});

// 2. Full Database State
app.get('/api/database', (req: Request, res: Response) => {
  res.json(db);
});

// 3. Reset Database to Starter Packs
app.post('/api/database/reset', (req: Request, res: Response) => {
  db = {
    materials: [...STARTER_MATERIALS],
    flashcards: [...STARTER_FLASHCARDS],
    quizQuestions: [...STARTER_QUIZZES],
    quizResults: [],
    chatHistory: {},
    lastUpdated: Date.now(),
  };
  saveDatabase(db);
  res.json({ success: true, message: 'Database reset to default study packs successfully', db });
});

// 4. Import Database State
app.post('/api/database/import', (req: Request, res: Response) => {
  try {
    const imported = req.body as DatabaseSchema;
    if (imported && Array.isArray(imported.materials)) {
      db = {
        materials: imported.materials || [],
        flashcards: imported.flashcards || [],
        quizQuestions: imported.quizQuestions || [],
        quizResults: imported.quizResults || [],
        chatHistory: imported.chatHistory || {},
        lastUpdated: Date.now(),
      };
      saveDatabase(db);
      res.json({ success: true, message: 'Database imported successfully', db });
    } else {
      res.status(400).json({ error: 'Invalid database payload' });
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Import failed' });
  }
});

// 5. Materials CRUD
app.get('/api/materials', (req: Request, res: Response) => {
  res.json(db.materials);
});

app.post('/api/materials', (req: Request, res: Response) => {
  try {
    const { title, content, subject } = req.body;
    if (!content || !content.trim()) {
      return res.status(400).json({ error: 'Document content is required' });
    }

    const cleaned = cleanText(content);
    const words = countWords(cleaned);
    const readingTime = estimateReadingTime(words);
    const docId = 'doc-' + Date.now();

    const newMaterial: StudyMaterial = {
      id: docId,
      title: title && title.trim() ? title.trim() : 'Study Document ' + (db.materials.length + 1),
      content: cleaned,
      subject: subject && subject.trim() ? subject.trim() : 'General',
      wordCount: words,
      readingTimeMinutes: readingTime,
      createdAt: Date.now(),
      summary: '',
      keyTakeaways: [],
      isPreloaded: false,
    };

    db.materials.unshift(newMaterial);
    saveDatabase(db);

    res.status(201).json(newMaterial);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to create material' });
  }
});

app.put('/api/materials/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const index = db.materials.findIndex(m => m.id === id);
  if (index === -1) {
    return res.status(404).json({ error: 'Material not found' });
  }

  const current = db.materials[index];
  const { title, content, subject, summary, keyTakeaways } = req.body;

  if (title !== undefined) current.title = title;
  if (content !== undefined) {
    current.content = cleanText(content);
    current.wordCount = countWords(current.content);
    current.readingTimeMinutes = estimateReadingTime(current.wordCount);
  }
  if (subject !== undefined) current.subject = subject;
  if (summary !== undefined) current.summary = summary;
  if (keyTakeaways !== undefined) current.keyTakeaways = keyTakeaways;

  db.materials[index] = current;
  saveDatabase(db);
  res.json(current);
});

app.delete('/api/materials/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  db.materials = db.materials.filter(m => m.id !== id);
  db.flashcards = db.flashcards.filter(f => f.documentId !== id);
  db.quizQuestions = db.quizQuestions.filter(q => q.documentId !== id);
  delete db.chatHistory[id];
  saveDatabase(db);
  res.json({ success: true, message: 'Document and associated data deleted' });
});

// 6. Flashcards CRUD & Spaced Repetition
app.get('/api/flashcards', (req: Request, res: Response) => {
  const docId = req.query.docId as string;
  if (docId) {
    return res.json(db.flashcards.filter(f => f.documentId === docId));
  }
  res.json(db.flashcards);
});

app.post('/api/flashcards', (req: Request, res: Response) => {
  const { documentId, question, answer, topic, difficulty } = req.body;
  if (!question || !answer) {
    return res.status(400).json({ error: 'Question and answer are required' });
  }

  const newCard: FlashcardItem = {
    id: 'fc-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
    documentId: documentId || 'general',
    question: question.trim(),
    answer: answer.trim(),
    topic: topic || 'Core Concept',
    difficulty: difficulty || 'Medium',
    repetitionIntervalDays: 1,
    easeFactor: 2.5,
    reviewCount: 0,
    lastReviewedTimestamp: 0,
    isBookmarked: false,
  };

  db.flashcards.unshift(newCard);
  saveDatabase(db);
  res.status(201).json(newCard);
});

app.post('/api/flashcards/review', (req: Request, res: Response) => {
  const { cardId, rating } = req.body;
  const index = db.flashcards.findIndex(f => f.id === cardId);
  if (index === -1) {
    return res.status(404).json({ error: 'Card not found' });
  }

  const updatedCard = processReview(db.flashcards[index], Number(rating) || 3);
  db.flashcards[index] = updatedCard;
  saveDatabase(db);

  const docCards = db.flashcards.filter(f => f.documentId === updatedCard.documentId);
  const mastery = calculateDeckMastery(docCards);

  res.json({ card: updatedCard, mastery });
});

app.post('/api/flashcards/bookmark', (req: Request, res: Response) => {
  const { cardId } = req.body;
  const index = db.flashcards.findIndex(f => f.id === cardId);
  if (index === -1) {
    return res.status(404).json({ error: 'Card not found' });
  }

  db.flashcards[index].isBookmarked = !db.flashcards[index].isBookmarked;
  saveDatabase(db);
  res.json({ card: db.flashcards[index] });
});

// 7. Quiz CRUD & Results
app.get('/api/quiz-questions', (req: Request, res: Response) => {
  const docId = req.query.docId as string;
  if (docId) {
    return res.json(db.quizQuestions.filter(q => q.documentId === docId));
  }
  res.json(db.quizQuestions);
});

app.post('/api/quiz-results', (req: Request, res: Response) => {
  const result: QuizResult = req.body;
  result.id = 'qr-' + Date.now();
  result.timestamp = Date.now();
  db.quizResults.unshift(result);
  saveDatabase(db);
  res.status(201).json(result);
});

app.get('/api/quiz-results', (req: Request, res: Response) => {
  res.json(db.quizResults);
});

// 8. Chat History
app.get('/api/chats/:docId', (req: Request, res: Response) => {
  const { docId } = req.params;
  res.json(db.chatHistory[docId] || []);
});

app.post('/api/chats/:docId', (req: Request, res: Response) => {
  const { docId } = req.params;
  const { message } = req.body;
  if (!db.chatHistory[docId]) {
    db.chatHistory[docId] = [];
  }
  db.chatHistory[docId].push(message);
  saveDatabase(db);
  res.status(201).json(message);
});

// -----------------------------------------------------------------------------
// AI GENERATION ENDPOINTS (POWERED BY GEMINI 3.8 FLASH + HEURISTIC FALLBACKS)
// -----------------------------------------------------------------------------

// AI Summary & Key Exam Highlights
app.post('/api/generate-summary', async (req: Request, res: Response) => {
  const { documentId, title, content } = req.body;
  const docTitle = title || 'Study Document';
  const contextSlice = prepareContextForPrompt(content || '');

  if (ai && isGeminiConfigured) {
    try {
      const prompt = `Summarize the following study document: "${docTitle}".
Document Text:
${contextSlice}

Provide a well-structured response with:
1. "summary": A clear, engaging 2-paragraph executive overview covering the main themes and analytical context.
2. "keyTakeaways": An array of 4-6 high-yield, testable bullet points with key mechanisms, formulas, or rules.`;

      const response = await withTimeout(
        ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: prompt,
          config: {
            temperature: 0.3,
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                summary: { type: Type.STRING },
                keyTakeaways: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                },
              },
              required: ['summary', 'keyTakeaways'],
            },
          },
        }),
        3000
      );

      const parsed = JSON.parse(response.text || '{}');
      if (parsed.summary && Array.isArray(parsed.keyTakeaways)) {
        // Update in database if documentId provided
        if (documentId) {
          const doc = db.materials.find(m => m.id === documentId);
          if (doc) {
            doc.summary = parsed.summary;
            doc.keyTakeaways = parsed.keyTakeaways;
            saveDatabase(db);
          }
        }
        return res.json({ summary: parsed.summary, keyTakeaways: parsed.keyTakeaways, source: 'gemini' });
      }
    } catch (err: any) {
      console.warn('Gemini summary call failed, using heuristic fallback:', err.message);
    }
  }

  // Fallback Heuristic Generator
  const topics = extractPotentialTopics(content);
  const sentences = content.split(/(?<=[.!?])\s+/).filter((s: string) => s.length > 25);
  const summary = `Executive overview for ${docTitle}: This study material comprises ${countWords(content)} words focusing on core principles across ${topics.slice(0, 3).join(', ')}. Key analytical frameworks and definitions provide direct preparation for exams and problem solving.`;
  const keyTakeaways = sentences.slice(0, 4);

  if (documentId) {
    const doc = db.materials.find(m => m.id === documentId);
    if (doc) {
      doc.summary = summary;
      doc.keyTakeaways = keyTakeaways;
      saveDatabase(db);
    }
  }

  res.json({ summary, keyTakeaways, source: 'heuristic' });
});

// Document-Grounded AI Doubt Solver Chat
app.post('/api/ask-doubt', async (req: Request, res: Response) => {
  const { documentId, title, content, question, history } = req.body;
  if (!question || !question.trim()) {
    return res.status(400).json({ error: 'Question is required' });
  }

  const docTitle = title || 'Study Document';
  const contextSlice = prepareContextForPrompt(content || '');

  if (ai && isGeminiConfigured) {
    try {
      const systemInstruction = `You are StudyMind AI, a world-class academic tutor inspired by Google Gemini.
You help students master difficult coursework, lecture notes, and textbooks.

Document Under Study: "${docTitle}"
DOCUMENT EXCERPT:
${contextSlice}

Guidelines:
- Answer the student's question directly, clearly, and insightfully.
- Ground your explanation strictly in the document text, highlighting key terms in bold.
- Use bullet points and clear steps where helpful for exam revision.
- Include a brief 'Key Takeaway' at the end.`;

      // Build conversation contents
      const conversationContents: any[] = [];
      if (Array.isArray(history)) {
        for (const item of history.slice(-6)) {
          conversationContents.push({
            role: item.isUser ? 'user' : 'model',
            parts: [{ text: item.text }],
          });
        }
      }
      conversationContents.push({
        role: 'user',
        parts: [{ text: question }],
      });

      const response = await withTimeout(
        ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: conversationContents,
          config: {
            systemInstruction: systemInstruction,
            temperature: 0.5,
            topP: 0.95,
          },
        }),
        3000
      );

      const answer = response.text || 'I could not generate an answer at this time.';

      // Persist in chat history
      if (documentId) {
        if (!db.chatHistory[documentId]) db.chatHistory[documentId] = [];
        db.chatHistory[documentId].push(
          { id: 'msg-' + Date.now() + '-u', text: question, isUser: true, timestamp: Date.now() },
          { id: 'msg-' + Date.now() + '-m', text: answer, isUser: false, timestamp: Date.now() }
        );
        saveDatabase(db);
      }

      return res.json({ answer, source: 'gemini' });
    } catch (err: any) {
      console.warn('Gemini chat call failed, using heuristic fallback:', err.message);
    }
  }

  // Heuristic Grounded Fallback
  const qLower = question.toLowerCase();
  const sentences = (content || '').split(/(?<=[.!?])\s+/);
  const matched = sentences.filter((s: string) => {
    const sLower = s.toLowerCase();
    const words = qLower.split(/\s+/).filter((w: string) => w.length > 3);
    return words.some((w: string) => sLower.includes(w));
  });

  let fallbackAnswer = '';
  if (matched.length > 0) {
    fallbackAnswer = `Based on **${docTitle}**:\n\n${matched.slice(0, 3).join('\n\n')}\n\n**Key Takeaway**: This directly relates to your coursework concepts. Review the flashcards on this section for deeper active recall.`;
  } else {
    fallbackAnswer = `Based on your study notes in **${docTitle}**, this topic is essential for mastering the subject. Key concepts include foundational principles, standard problem mechanisms, and exam applications.\n\n*Tip: Connect your Gemini API key in AI Studio Secrets to unlock dynamic real-time doubt solving.*`;
  }

  if (documentId) {
    if (!db.chatHistory[documentId]) db.chatHistory[documentId] = [];
    db.chatHistory[documentId].push(
      { id: 'msg-' + Date.now() + '-u', text: question, isUser: true, timestamp: Date.now() },
      { id: 'msg-' + Date.now() + '-m', text: fallbackAnswer, isUser: false, timestamp: Date.now() }
    );
    saveDatabase(db);
  }

  res.json({ answer: fallbackAnswer, source: 'heuristic' });
});

// AI Flashcard Generation
app.post('/api/generate-flashcards', async (req: Request, res: Response) => {
  const { documentId, title, content, count = 6 } = req.body;
  const docTitle = title || 'Study Document';
  const contextSlice = prepareContextForPrompt(content || '');
  const numCards = Math.min(10, Math.max(3, Number(count) || 6));

  if (ai && isGeminiConfigured) {
    try {
      const prompt = `Create ${numCards} active recall study flashcards from the document "${docTitle}".
DOCUMENT CONTENT:
${contextSlice}

Requirements:
- Each card must have a focused, clear 'question' (e.g. definition, contrast, process, or mechanism).
- Each card must have a concise, accurate 'answer' (2-3 sentences max).
- 'topic': Sub-topic category name.
- 'difficulty': "Easy", "Medium", or "Hard".`;

      const response = await withTimeout(
        ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: prompt,
          config: {
            temperature: 0.4,
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  question: { type: Type.STRING },
                  answer: { type: Type.STRING },
                  topic: { type: Type.STRING },
                  difficulty: { type: Type.STRING },
                },
                required: ['question', 'answer', 'topic', 'difficulty'],
              },
            },
          },
        }),
        3000
      );

      const parsed = JSON.parse(response.text || '[]');
      if (Array.isArray(parsed) && parsed.length > 0) {
        const newCards: FlashcardItem[] = parsed.map((item: any, idx: number) => ({
          id: 'fc-' + Date.now() + '-' + idx,
          documentId: documentId || 'general',
          question: item.question || 'Study Question',
          answer: item.answer || 'Study Answer',
          topic: item.topic || 'Core Concept',
          difficulty: (['Easy', 'Medium', 'Hard'].includes(item.difficulty) ? item.difficulty : 'Medium') as any,
          repetitionIntervalDays: 1,
          easeFactor: 2.5,
          reviewCount: 0,
          lastReviewedTimestamp: 0,
          isBookmarked: false,
        }));

        db.flashcards.unshift(...newCards);
        saveDatabase(db);

        return res.json({ flashcards: newCards, source: 'gemini' });
      }
    } catch (err: any) {
      console.warn('Gemini flashcards call failed, using heuristic fallback:', err.message);
    }
  }

  // Heuristic Fallback
  const topics = extractPotentialTopics(content);
  const sentences = (content || '').split(/(?<=[.!?])\s+/).filter((s: string) => s.length > 25);
  const fallbackCards: FlashcardItem[] = [];

  for (let i = 0; i < Math.min(numCards, sentences.length); i++) {
    const topic = topics[i % topics.length] || 'Key Concept';
    fallbackCards.push({
      id: 'fc-' + Date.now() + '-' + i,
      documentId: documentId || 'general',
      question: `What is the key takeaway regarding '${topic}' in ${docTitle}?`,
      answer: sentences[i],
      topic: topic,
      difficulty: i % 2 === 0 ? 'Medium' : 'Easy',
      repetitionIntervalDays: 1,
      easeFactor: 2.5,
      reviewCount: 0,
      lastReviewedTimestamp: 0,
      isBookmarked: false,
    });
  }

  db.flashcards.unshift(...fallbackCards);
  saveDatabase(db);
  res.json({ flashcards: fallbackCards, source: 'heuristic' });
});

// AI Quiz Generation
app.post('/api/generate-quiz', async (req: Request, res: Response) => {
  const { documentId, title, content, count = 5 } = req.body;
  const docTitle = title || 'Study Document';
  const contextSlice = prepareContextForPrompt(content || '');
  const numQuestions = Math.min(8, Math.max(3, Number(count) || 5));

  if (ai && isGeminiConfigured) {
    try {
      const prompt = `Generate ${numQuestions} rigorous multiple-choice practice quiz questions from "${docTitle}".
DOCUMENT CONTENT:
${contextSlice}

Requirements:
- 'question': Clear question statement testing understanding, mechanisms, or principles.
- 'options': Exactly 4 distinct plausible options (strings).
- 'correctAnswerIndex': Integer 0, 1, 2, or 3 pointing to the correct option.
- 'explanation': Clear pedagogical explanation detailing WHY the correct option is right and common pitfalls.`;

      const response = await withTimeout(
        ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: prompt,
          config: {
            temperature: 0.4,
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  question: { type: Type.STRING },
                  options: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                  },
                  correctAnswerIndex: { type: Type.INTEGER },
                  explanation: { type: Type.STRING },
                },
                required: ['question', 'options', 'correctAnswerIndex', 'explanation'],
              },
            },
          },
        }),
        3000
      );

      const parsed = JSON.parse(response.text || '[]');
      if (Array.isArray(parsed) && parsed.length > 0) {
        const newQuestions: QuizQuestion[] = parsed.map((item: any, idx: number) => ({
          id: 'q-' + Date.now() + '-' + idx,
          documentId: documentId || 'general',
          questionText: item.question,
          options: Array.isArray(item.options) && item.options.length === 4 ? item.options : ['Option A', 'Option B', 'Option C', 'Option D'],
          correctAnswerIndex: typeof item.correctAnswerIndex === 'number' && item.correctAnswerIndex >= 0 && item.correctAnswerIndex <= 3 ? item.correctAnswerIndex : 0,
          explanation: item.explanation || 'Directly aligned with your study material.',
        }));

        // Replace or add to quiz questions
        db.quizQuestions = db.quizQuestions.filter(q => q.documentId !== documentId).concat(newQuestions);
        saveDatabase(db);

        return res.json({ questions: newQuestions, source: 'gemini' });
      }
    } catch (err: any) {
      console.warn('Gemini quiz call failed, using heuristic fallback:', err.message);
    }
  }

  // Heuristic Fallback
  const sentences = (content || '').split(/(?<=[.!?])\s+/).filter((s: string) => s.length > 25);
  const fallbackQuestions: QuizQuestion[] = [];

  for (let i = 0; i < Math.min(numQuestions, sentences.length); i++) {
    const correctStatement = sentences[i].slice(0, 100);
    fallbackQuestions.push({
      id: 'q-' + Date.now() + '-' + i,
      documentId: documentId || 'general',
      questionText: `Which of the following statements accurately reflects the material in "${docTitle}"?`,
      options: [
        correctStatement,
        'This statement directly contradicts the core principles presented in the text.',
        'An inverse relationship that is not supported by the analytical evidence.',
        'None of the provided options accurately describe the mechanism.',
      ],
      correctAnswerIndex: 0,
      explanation: `Directly stated in your notes: "${correctStatement}"`,
    });
  }

  db.quizQuestions = db.quizQuestions.filter(q => q.documentId !== documentId).concat(fallbackQuestions);
  saveDatabase(db);
  res.json({ questions: fallbackQuestions, source: 'heuristic' });
});

// Concept Explanation (ELI5 vs Deep Academic Breakdown)
app.post('/api/explain-concept', async (req: Request, res: Response) => {
  const { concept, content, isSimplified = true } = req.body;
  if (!concept || !concept.trim()) {
    return res.status(400).json({ error: 'Concept name is required' });
  }

  const contextSlice = prepareContextForPrompt(content || '');

  if (ai && isGeminiConfigured) {
    try {
      const modeInstruction = isSimplified
        ? 'Explain this concept simply using an intuitive everyday analogy (suitable for a beginner or high schooler), in 2-3 short, vivid paragraphs.'
        : 'Provide an in-depth academic breakdown with technical precision, underlying principles, mechanisms, and common exam questions.';

      const prompt = `Concept: "${concept}"

Context from study material:
${contextSlice}

Instruction:
${modeInstruction}`;

      const response = await withTimeout(
        ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: prompt,
          config: {
            temperature: 0.6,
            topP: 0.95,
          },
        }),
        3000
      );

      return res.json({ explanation: response.text || 'No explanation generated.', source: 'gemini' });
    } catch (err: any) {
      console.warn('Gemini explain concept call failed, using heuristic fallback:', err.message);
    }
  }

  // Heuristic fallback
  const explanation = isSimplified
    ? `Think of **${concept}** like an everyday everyday system: when inputs are provided, standard rules process them predictably to deliver the intended output without bottlenecks. In your study notes, this provides the foundational link for subsequent topics.`
    : `**${concept}** represents a fundamental theorem in this domain. Key tenets require understanding the boundary conditions, state transitions, and performance trade-offs outlined in your material. Review the flashcard deck to solidify memorization of its formal proof and equations.`;

  res.json({ explanation, source: 'heuristic' });
});

// -----------------------------------------------------------------------------
// VITE DEV SERVER / STATIC SERVING
// -----------------------------------------------------------------------------

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`StudyMind AI server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
